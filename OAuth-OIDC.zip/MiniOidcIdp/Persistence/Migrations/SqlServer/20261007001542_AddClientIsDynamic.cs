﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace MiniOidcIdp.Persistence.Migrations.SqlServer
{
    /// <inheritdoc />
    public partial class AddClientIsDynamic : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            // Default true: every pre-existing row was registered through the old, always-dynamic /register
            // path, so backfilling them as dynamic (consent-required) preserves their current behavior.
            migrationBuilder.AddColumn<bool>(
                name: "IsDynamic",
                table: "Clients",
                type: "bit",
                nullable: false,
                defaultValue: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "IsDynamic",
                table: "Clients");
        }
    }
}
