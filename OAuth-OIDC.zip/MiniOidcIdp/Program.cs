using System.Net;
using System.Security.Cryptography;
using System.Security.Principal;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using Microsoft.AspNetCore.Antiforgery;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Negotiate;
using Microsoft.AspNetCore.Http.Features;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Server.IISIntegration;
using Microsoft.AspNetCore.WebUtilities;
using Microsoft.Extensions.Primitives;

var builder = WebApplication.CreateBuilder(args);

// 0. Configuration: how users sign in, which groups map to which roles, who may edit the mappings, and where state is kept
var idp = builder.Configuration.GetSection("Idp").Get<IdpOptions>() ?? new IdpOptions();
bool windowsMode = idp.AuthenticationMode != IdpMode.Persona;

if (windowsMode && !OperatingSystem.IsWindows())
{
    throw new InvalidOperationException($"Idp:AuthenticationMode '{idp.AuthenticationMode}' needs Windows. Use 'Persona' on this machine.");
}

string windowsScheme = idp.AuthenticationMode == IdpMode.WindowsIis ? IISDefaults.AuthenticationScheme : NegotiateDefaults.AuthenticationScheme;
if (idp.AuthenticationMode == IdpMode.WindowsKestrel)
{
    builder.Services.AddAuthentication(NegotiateDefaults.AuthenticationScheme).AddNegotiate();
}
else if (idp.AuthenticationMode == IdpMode.WindowsIis)
{
    builder.Services.AddAuthentication(IISDefaults.AuthenticationScheme);
}

// Stores for clients, codes, refresh tokens, role mappings and signing keys: in memory by default, or a database
var persistence = builder.Services.AddIdpPersistence(builder.Configuration, idp);
builder.Services.AddAntiforgery();

var app = builder.Build();

// Only needed when deployed under a sub-path (e.g. an IIS Application at /oidc, not a site's root). IIS/ANCM already
// sets the incoming PathBase automatically in that case, so this mainly guards against a known .NET 10 in-process
// hosting regression where the very first request after a cold start can arrive with an empty PathBase.
if (!string.IsNullOrWhiteSpace(idp.PathBase))
{
    app.UsePathBase(idp.PathBase);
}

// Creates the schema, seeds the role mappings and makes sure a signing key exists. Stops the IdP if anything is wrong.
await app.Services.InitializeIdpPersistenceAsync(idp);

if (windowsMode)
{
    app.UseAuthentication();
}

var clients = app.Services.GetRequiredService<IClientStore>();
var staticClients = app.Services.GetRequiredService<StaticClients>();
var codeStore = app.Services.GetRequiredService<IAuthorizationCodeStore>();
var refreshStore = app.Services.GetRequiredService<IRefreshTokenStore>();
var roleMappings = app.Services.GetRequiredService<IRoleMappingStore>();
var keys = app.Services.GetRequiredService<ISigningKeyProvider>();

app.Logger.LogInformation("Authentication mode: {Mode}. State kept in: {Provider}", idp.AuthenticationMode, persistence.Provider == PersistenceProvider.None ? "memory" : persistence.Provider.ToString());

// The resources tokens may be issued for, keyed by a normalised address so trivial differences (host case, a trailing slash) still match
static string ResourceKey(Uri uri) => uri.GetLeftPart(UriPartial.Authority) + uri.AbsolutePath.TrimEnd('/') + uri.Query;

var registeredResources = new Dictionary<string, ResourceOptions>();
foreach (var configured in idp.Resources)
{
    if (!Uri.TryCreate(configured.Resource, UriKind.Absolute, out var configuredUri) || !string.IsNullOrEmpty(configuredUri.Fragment)
        || !registeredResources.TryAdd(ResourceKey(configuredUri), configured))
    {
        throw new InvalidOperationException($"Idp:Resources entry '{configured.Resource}' is not an absolute URI without a fragment, or is listed twice.");
    }
}

bool enforceResources = registeredResources.Count > 0;

// Scopes any client may ask for, whichever resource it names: the OpenID Connect ones, and offline_access for a refresh token
string[] baseScopes = ["openid", "profile", "email", "offline_access"];
if (!enforceResources)
{
    app.Logger.LogWarning("Idp:Resources is empty, so tokens are issued for any resource address and any scope. List your APIs and MCP servers there before using this for real.");
}

var pkceChallenge = new Regex("^[A-Za-z0-9_-]{43}$", RegexOptions.Compiled);
var pkceVerifier = new Regex("^[A-Za-z0-9._~-]{43,128}$", RegexOptions.Compiled);

int accessTokenSeconds = Math.Max(1, app.Configuration.GetValue<int>("Tokens:AccessTokenSeconds", 3600));
int refreshTokenSeconds = Math.Max(1, app.Configuration.GetValue<int>("Tokens:RefreshTokenSeconds", 86400));
int refreshTokenMaxSeconds = Math.Max(1, app.Configuration.GetValue<int>("Tokens:RefreshTokenMaxSeconds", 604800));
int authorizationCodeSeconds = Math.Max(1, app.Configuration.GetValue<int>("Tokens:AuthorizationCodeSeconds", 300));

const int MaxDynamicClients = 1000;
const int MaxRedirectUris = 10;
const int MaxUriLength = 2048;
const int MaxClientNameLength = 200;

string IssuerFor(HttpRequest r) =>
    !string.IsNullOrWhiteSpace(idp.Issuer) ? idp.Issuer.TrimEnd('/') : $"{r.Scheme}://{r.Host}{r.PathBase}";
string Html(string? s) => WebUtility.HtmlEncode(s ?? "");

// Entra ID's sub is pairwise: the same user gets a different, opaque sub for every different client_id, unlike oid
// (here, the user's Subject/SID) which stays constant. Mirrored here so code written against sub can't accidentally
// treat it as a stable user key the way oid is.
string Pairwise(string oid, string clientId) => Base64Url.Encode(SHA256.HashData(Encoding.UTF8.GetBytes($"{oid}|{clientId}")))[..27];

var indented = new JsonSerializerOptions(JsonSerializerDefaults.Web) { WriteIndented = true };

// Windows sign-in: the server (IIS) or the Negotiate handler (Kestrel) does the NTLM/Kerberos handshake for us
async Task<IdpUser?> AuthenticateWindowsAsync(HttpContext ctx)
{
    var result = await ctx.AuthenticateAsync(windowsScheme);
    if (result.Succeeded && OperatingSystem.IsWindows() && result.Principal?.Identity is WindowsIdentity identity)
    {
        return IdpUsers.FromWindows(identity);
    }

    return null;
}

IResult ChallengeWindows() => Results.Challenge(authenticationSchemes: new[] { windowsScheme });

// Authorization server metadata, served both as OIDC discovery and as RFC 8414 metadata (MCP clients look for either)
object ServerMetadata(string issuer)
{
    var metadata = new Dictionary<string, object>
    {
        ["issuer"] = issuer,
        ["authorization_endpoint"] = $"{issuer}/authorize",
        ["token_endpoint"] = $"{issuer}/token",
        ["jwks_uri"] = $"{issuer}/.well-known/jwks.json",
        ["revocation_endpoint"] = $"{issuer}/revoke",
        ["revocation_endpoint_auth_methods_supported"] = new[] { "none" },
        ["end_session_endpoint"] = $"{issuer}/logout",
        ["response_types_supported"] = new[] { "code" },
        ["grant_types_supported"] = new[] { "authorization_code", "refresh_token" },
        ["subject_types_supported"] = new[] { "public" },
        ["id_token_signing_alg_values_supported"] = new[] { "RS256" },
        ["code_challenge_methods_supported"] = new[] { "S256" },
        ["token_endpoint_auth_methods_supported"] = new[] { "none" },
        ["scopes_supported"] = enforceResources
            ? baseScopes.Concat(registeredResources.Values.SelectMany(r => r.Scopes)).Distinct().ToArray()
            : new[] { "openid", "offline_access", "mcp:tools" },
        // RFC 9207: every authorization response (success or error) carries iss, so a client can tell which server answered
        ["authorization_response_iss_parameter_supported"] = true
    };

    if (idp.AllowDynamicClientRegistration)
    {
        metadata["registration_endpoint"] = $"{issuer}/register";
    }

    return metadata;
}

app.MapGet("/.well-known/openid-configuration", (HttpRequest request) => Results.Json(ServerMetadata(IssuerFor(request))));
app.MapGet("/.well-known/oauth-authorization-server", (HttpRequest request) => Results.Json(ServerMetadata(IssuerFor(request))));

// Public signing keys (JWK) used to verify the RS256 signature on issued tokens. During a rotation this lists more than one.
app.MapGet("/.well-known/jwks.json", async () =>
{
    var published = await keys.GetPublishedAsync();
    return Results.Json(new
    {
        keys = published.Select(k => new { kty = "RSA", use = "sig", alg = "RS256", kid = k.Kid, n = k.Modulus, e = k.Exponent })
    });
});

// Dynamic Client Registration (RFC 7591): public clients register their redirect URIs and receive a client_id
app.MapPost("/register", async (HttpContext context) =>
{
    if (!idp.AllowDynamicClientRegistration)
    {
        return Results.NotFound();
    }

    // The endpoint is open to anyone, so keep what it accepts small
    var bodyLimit = context.Features.Get<IHttpMaxRequestBodySizeFeature>();
    if (bodyLimit is { IsReadOnly: false })
    {
        bodyLimit.MaxRequestBodySize = 32 * 1024;
    }

    JsonDocument document;
    try
    {
        document = await JsonDocument.ParseAsync(context.Request.Body);
    }
    catch (JsonException)
    {
        return Results.Json(new { error = "invalid_client_metadata", error_description = "Body must be JSON" }, statusCode: 400);
    }

    using (document)
    {
        var body = document.RootElement;
        if (body.ValueKind != JsonValueKind.Object)
        {
            return Results.Json(new { error = "invalid_client_metadata", error_description = "Body must be a JSON object" }, statusCode: 400);
        }

        string? clientName = body.TryGetProperty("client_name", out var nameElement) && nameElement.ValueKind == JsonValueKind.String ? nameElement.GetString() : null;
        if (clientName is { Length: > MaxClientNameLength })
        {
            return Results.Json(new { error = "invalid_client_metadata", error_description = $"client_name is limited to {MaxClientNameLength} characters" }, statusCode: 400);
        }

        var redirectUris = ReadUriList(body, "redirect_uris", out var redirectError);
        if (redirectUris == null || redirectUris.Count == 0)
        {
            return Results.Json(new { error = "invalid_redirect_uri", error_description = redirectError ?? "redirect_uris is required" }, statusCode: 400);
        }

        var postLogoutUris = ReadUriList(body, "post_logout_redirect_uris", out var postLogoutError) ?? [];
        if (postLogoutError != null)
        {
            return Results.Json(new { error = "invalid_client_metadata", error_description = postLogoutError }, statusCode: 400);
        }

        string clientId = "client_" + Convert.ToHexString(RandomNumberGenerator.GetBytes(8));
        if (!await clients.TryRegisterAsync(new ClientInfo(clientId, redirectUris, postLogoutUris, clientName, Dynamic: true), clientName, MaxDynamicClients))
        {
            return Results.Json(new { error = "invalid_client_metadata", error_description = "The limit on registered clients has been reached" }, statusCode: 400);
        }

        return Results.Json(new
        {
            client_id = clientId,
            client_id_issued_at = DateTimeOffset.UtcNow.ToUnixTimeSeconds(),
            client_name = clientName,
            redirect_uris = redirectUris,
            post_logout_redirect_uris = postLogoutUris,
            token_endpoint_auth_method = "none",
            grant_types = new[] { "authorization_code", "refresh_token" },
            response_types = new[] { "code" }
        }, statusCode: 201);
    }
});

// Reads an optional array of redirect-style URIs. Returns null with an error message when a value is not acceptable.
List<string>? ReadUriList(JsonElement body, string name, out string? error)
{
    error = null;
    var list = new List<string>();
    if (!body.TryGetProperty(name, out var element))
    {
        return list;
    }

    if (element.ValueKind != JsonValueKind.Array || element.GetArrayLength() > MaxRedirectUris)
    {
        error = $"{name} must be an array of at most {MaxRedirectUris} URIs";
        return null;
    }

    foreach (var item in element.EnumerateArray())
    {
        string? uri = item.ValueKind == JsonValueKind.String ? item.GetString() : null;
        if (uri is not { Length: <= MaxUriLength } || !IsAcceptableRedirectUri(uri))
        {
            error = $"{name} must hold absolute https URIs or http loopback URIs, without fragments, of at most {MaxUriLength} characters";
            return null;
        }

        if (!list.Contains(uri))
        {
            list.Add(uri);
        }
    }

    return list;
}

// 2. Endpoint: The Initial OIDC Redirection Trigger (Step 1 & 2 of the Flow)
app.MapGet("/authorize", async (HttpContext context, IAntiforgery antiforgery, [FromQuery] string? client_id, [FromQuery] string? redirect_uri, [FromQuery] string? response_type,
    [FromQuery] string? code_challenge, [FromQuery] string? code_challenge_method, [FromQuery] string? scope, [FromQuery] string? state, [FromQuery] string? nonce) =>
{
    scope = NullIfEmpty(scope);
    state = NullIfEmpty(state);
    nonce = NullIfEmpty(nonce);

    var check = await ValidateAuthorizationRequestAsync(client_id, redirect_uri, response_type, code_challenge, code_challenge_method, NonEmpty(context.Request.Query["resource"]), scope);
    var failure = Failure(context, check, redirect_uri, state);
    if (failure != null)
    {
        return failure;
    }

    // Windows modes: no login form. The browser answers the Windows challenge, so the user is signed in without being asked anything.
    if (windowsMode)
    {
        var user = await AuthenticateWindowsAsync(context);
        if (user == null)
        {
            return ChallengeWindows();
        }

        // A client that registered itself at /register could be anybody, and the user has just been signed in without a word,
        // so they must be shown who is asking before a code goes anywhere. Clients fixed in configuration are trusted.
        if (check.Client!.Dynamic)
        {
            return ConsentPage(context, antiforgery, user, check.Client, redirect_uri!, code_challenge!, check.Audience, scope, state, nonce);
        }

        return await IssueCodeAsync(context, user, client_id!, redirect_uri!, code_challenge!, check.Audience, scope, state, nonce);
    }

    // Persona mode: the login form, prefilled with the first persona so a first-time visitor can just click the button
    return LoginForm(context.Request.PathBase, client_id!, redirect_uri!, code_challenge!, code_challenge_method!, check.Audience, scope, state, nonce,
        idp.Personas.FirstOrDefault()?.Email ?? "", idp.Personas.FirstOrDefault()?.Password ?? "", null);
});

// Shown to a signed-in user when a self-registered client asks for a code. Nothing is issued until they press Allow, and the
// anti-forgery token stops another site posting "allow" for them (their browser would add the Windows credentials by itself).
IResult ConsentPage(HttpContext context, IAntiforgery antiforgery, IdpUser user, ClientInfo client, string redirectUri, string codeChallenge, string? resource, string? scope, string? state, string? nonce)
{
    var tokens = antiforgery.GetAndStoreTokens(context);
    string[] scopes = SplitScopes(scope);
    string scopeHtml = scopes.Length == 0
        ? "<li>Basic sign-in only</li>"
        : string.Join("", scopes.Select(s => $"<li>{Html(s)}{(s == "offline_access" ? " (stay signed in without asking you again)" : "")}</li>"));

    var html = Ui.CenteredPage("Allow this application?", $@"
            <h2>Allow this application?</h2>
            <p>You are signed in as <b>{Html(user.Account)}</b>.</p>
            <p>An application calling itself <b>{Html(client.Name ?? "(no name given)")}</b> is asking to sign you in. It registered itself with this server, so its name has not been checked by anyone.</p>
            <ul>
                <li>After you click Allow, your browser is sent to <b>{Html(redirectUri)}</b> carrying a sign-in code for your account.</li>
                <li>It would be able to act as you{(resource == null ? "" : $" at <b>{Html(resource)}</b>")}, with these permissions:<ul>{scopeHtml}</ul></li>
            </ul>
            <p class='alert alert-info'>Only continue if you just started this from that application.</p>
            <form action='{context.Request.PathBase}/authorize/consent' method='POST'>
                <input type='hidden' name='{Html(tokens.FormFieldName)}' value='{Html(tokens.RequestToken)}' />
                <input type='hidden' name='client_id' value='{Html(client.ClientId)}' />
                <input type='hidden' name='redirect_uri' value='{Html(redirectUri)}' />
                <input type='hidden' name='code_challenge' value='{Html(codeChallenge)}' />
                <input type='hidden' name='resource' value='{Html(resource)}' />
                <input type='hidden' name='scope' value='{Html(scope)}' />
                <input type='hidden' name='state' value='{Html(state)}' />
                <input type='hidden' name='nonce' value='{Html(nonce)}' />
                <button type='submit' name='decision' value='allow' class='btn'>Allow</button>
                <button type='submit' name='decision' value='deny' class='btn btn-secondary'>Cancel</button>
            </form>");

    return Results.Content(html, "text/html; charset=utf-8");
}

app.MapPost("/authorize/consent", async (HttpContext context, IAntiforgery antiforgery) =>
{
    if (!windowsMode)
    {
        return Results.NotFound();
    }

    try
    {
        await antiforgery.ValidateRequestAsync(context);
    }
    catch (AntiforgeryValidationException)
    {
        return Results.BadRequest(new { error = "invalid_request", error_description = "Missing or invalid anti-forgery token" });
    }

    var user = await AuthenticateWindowsAsync(context);
    if (user == null)
    {
        return ChallengeWindows();
    }

    // The form fields are attacker-controllable, so everything is validated again, exactly as at /authorize
    var form = await context.Request.ReadFormAsync();
    string? clientId = NullIfEmpty(form["client_id"].ToString());
    string? redirectUri = NullIfEmpty(form["redirect_uri"].ToString());
    string? codeChallenge = NullIfEmpty(form["code_challenge"].ToString());
    string? scope = NullIfEmpty(form["scope"].ToString());
    string? state = NullIfEmpty(form["state"].ToString());
    string? nonce = NullIfEmpty(form["nonce"].ToString());

    var check = await ValidateAuthorizationRequestAsync(clientId, redirectUri, "code", codeChallenge, "S256", NonEmpty(form["resource"]), scope);
    var failure = Failure(context, check, redirectUri, state);
    if (failure != null)
    {
        return failure;
    }

    if (form["decision"].ToString() != "allow")
    {
        app.Logger.LogInformation("{Account} declined client {Client}", user.Account, clientId);
        return AuthorizationError(context, redirectUri!, state, "access_denied", "The user did not allow the request");
    }

    app.Logger.LogInformation("{Account} allowed client {Client} ({Name}) to receive a code at {Redirect}", user.Account, clientId, check.Client!.Name, redirectUri);
    return await IssueCodeAsync(context, user, clientId!, redirectUri!, codeChallenge!, check.Audience, scope, state, nonce);
});

// A lightweight, raw HTML login form. It is also shown again, with an error, when a sign-in fails.
IResult LoginForm(PathString pathBase, string clientId, string redirectUri, string codeChallenge, string codeChallengeMethod, string? resource, string? scope, string? state, string? nonce, string email, string password, string? errorMessage)
{
    string errorHtml = errorMessage == null ? "" : $"<p role='alert' class='alert alert-error'>{Html(errorMessage)}</p>";

    var html = Ui.CenteredPage("Sign in", $@"
            <h2>Sign in</h2>
            {errorHtml}
            <form action='{pathBase}/login' method='POST'>
                <!-- Pass along the client parameters hidden so the form submission keeps context -->
                <input type='hidden' name='client_id' value='{Html(clientId)}' />
                <input type='hidden' name='redirect_uri' value='{Html(redirectUri)}' />
                <input type='hidden' name='code_challenge' value='{Html(codeChallenge)}' />
                <input type='hidden' name='code_challenge_method' value='{Html(codeChallengeMethod)}' />
                <input type='hidden' name='resource' value='{Html(resource)}' />
                <input type='hidden' name='scope' value='{Html(scope)}' />
                <input type='hidden' name='state' value='{Html(state)}' />
                <input type='hidden' name='nonce' value='{Html(nonce)}' />

                <div class='field'>
                    <label for='email'>Email</label>
                    <input type='email' id='email' name='email' value='{Html(email)}' required />
                </div>
                <div class='field'>
                    <label for='password'>Password</label>
                    <input type='password' id='password' name='password' value='{Html(password)}' required />
                </div>
                <button type='submit' class='btn btn-block'>Sign In &amp; Grant Consent</button>
            </form>");

    return Results.Content(html, "text/html; charset=utf-8");
}

// 3. Endpoint: Form Post-Back Process (Step 3 & 4 of the Flow), Persona mode only
app.MapPost("/login", async (HttpContext context) =>
{
    if (windowsMode)
    {
        return Results.NotFound();
    }

    var form = await context.Request.ReadFormAsync();
    string email = form["email"].ToString();
    string password = form["password"].ToString();
    string? clientId = NullIfEmpty(form["client_id"].ToString());
    string? redirectUri = NullIfEmpty(form["redirect_uri"].ToString());
    string? codeChallenge = NullIfEmpty(form["code_challenge"].ToString());
    string codeChallengeMethod = form["code_challenge_method"].ToString();
    string? scope = NullIfEmpty(form["scope"].ToString());
    string? state = NullIfEmpty(form["state"].ToString());
    string? nonce = NullIfEmpty(form["nonce"].ToString());

    // The form fields are attacker-controllable, so the request is validated again here, not just at /authorize
    var check = await ValidateAuthorizationRequestAsync(clientId, redirectUri, "code", codeChallenge, codeChallengeMethod, NonEmpty(form["resource"]), scope);
    var failure = Failure(context, check, redirectUri, state);
    if (failure != null)
    {
        return failure;
    }

    // Validate Credentials. A wrong password shows the form again with a generic message (no hint about which part was wrong)
    // and keeps the request details, so the user can retry. The password is never echoed back.
    var persona = idp.Personas.FirstOrDefault(p => string.Equals(p.Email, email, StringComparison.OrdinalIgnoreCase));
    if (persona == null || persona.Password != password)
    {
        return LoginForm(context.Request.PathBase, clientId!, redirectUri!, codeChallenge!, codeChallengeMethod, check.Audience, scope, state, nonce, email, "", "Incorrect email or password.");
    }

    return await IssueCodeAsync(context, IdpUsers.FromPersona(persona), clientId!, redirectUri!, codeChallenge!, check.Audience, scope, state, nonce);
});

// Creates the one-time authorization code for a signed-in user and redirects back to the client
async Task<IResult> IssueCodeAsync(HttpContext context, IdpUser user, string clientId, string redirectUri, string codeChallenge, string? resource, string? scope, string? state, string? nonce)
{
    // Groups become application roles here, at sign-in, using the current mapping table
    string[] roles = IdpUsers.ResolveRoles(user, await roleMappings.SnapshotAsync());

    // Generate a secure, randomized one-time authorization code
    string authorizationCode = "auth_" + Convert.ToHexString(RandomNumberGenerator.GetBytes(16));

    // Keep what it stands for until the client trades it in at /token, or it expires
    await codeStore.SaveAsync(authorizationCode, new AuthFlowSession(clientId, redirectUri, codeChallenge, user.Subject, user.Account, user.Name, roles, resource, scope, nonce),
        DateTimeOffset.UtcNow.AddSeconds(authorizationCodeSeconds));

    // Redirect the browser window straight back to the client application with the code (and the client's state, if any).
    // iss (RFC 9207) names this server, so a client that talks to several can tell a response from one it did not ask.
    var callbackParams = new Dictionary<string, string?> { ["code"] = authorizationCode, ["iss"] = IssuerFor(context.Request) };
    if (state != null)
    {
        callbackParams["state"] = state;
    }
    return Results.Redirect(QueryHelpers.AddQueryString(redirectUri, callbackParams));
}

// 4. Endpoint: /token. Two grants: authorization_code (Steps 5-7 of the flow) and refresh_token.
app.MapPost("/token", async (HttpContext context) =>
{
    context.Response.Headers.CacheControl = "no-store";

    var form = await context.Request.ReadFormAsync();
    return form["grant_type"].ToString() switch
    {
        "" or "authorization_code" => await ExchangeAuthorizationCodeAsync(context, form),
        "refresh_token" => await ExchangeRefreshTokenAsync(context, form),
        _ => TokenError("unsupported_grant_type", "Supported grants: authorization_code, refresh_token")
    };
});

IResult TokenError(string error, string description) =>
    Results.Json(new { error, error_description = description }, statusCode: StatusCodes.Status400BadRequest);

string[] SplitScopes(string? scope) =>
    string.IsNullOrWhiteSpace(scope) ? [] : scope.Split(' ', StringSplitOptions.RemoveEmptyEntries);

async Task<IResult> ExchangeAuthorizationCodeAsync(HttpContext context, IFormCollection form)
{
    string? code = form["code"];
    string? codeVerifier = form["code_verifier"];

    if (string.IsNullOrEmpty(code) || string.IsNullOrEmpty(codeVerifier))
    {
        return TokenError("invalid_request", "code and code_verifier are required");
    }

    // Every refresh token issued from this login shares a family id, so a replayed one can revoke them all. The same id is the token's sid claim.
    // It is worked out from the code itself, so a second attempt with the same code can find and end whatever the first one produced.
    string familyId = Base64Url.Encode(SHA256.HashData(Encoding.UTF8.GetBytes("family|" + code)))[..16];

    // Burn the code first so it is strictly single-use, and stays burned however the rest of this request goes (a wrong verifier
    // included, so a code cannot be guessed at). A code that is unknown or already used means it was replayed or intercepted:
    // RFC 6749 says to end the tokens it already produced. If two requests race, the loser lands here and takes the winner's with it.
    var session = await codeStore.FindAsync(code);
    if (session == null || !await codeStore.ConsumeAsync(code))
    {
        await refreshStore.RevokeFamilyAsync(familyId);
        return TokenError("invalid_grant", "Code not found or expired");
    }

    // PKCE Verification. RFC 7636 fixes the verifier's alphabet and length, and the comparison takes the same time whatever it finds.
    string computedChallenge = Base64Url.Encode(SHA256.HashData(Encoding.UTF8.GetBytes(codeVerifier)));
    if (!pkceVerifier.IsMatch(codeVerifier)
        || !CryptographicOperations.FixedTimeEquals(Encoding.UTF8.GetBytes(computedChallenge), Encoding.UTF8.GetBytes(session.CodeChallenge)))
    {
        return TokenError("invalid_grant", "PKCE verification failed");
    }

    // If the client repeats these parameters at the token endpoint, they must match the authorization request
    string? tokenClientId = NullIfEmpty(form["client_id"].ToString());
    string? tokenRedirectUri = NullIfEmpty(form["redirect_uri"].ToString());

    if ((tokenClientId != null && tokenClientId != session.ClientId) || (tokenRedirectUri != null && tokenRedirectUri != session.RedirectUri))
    {
        return TokenError("invalid_grant", "client_id or redirect_uri does not match the authorization request");
    }

    var resourceError = ResolveResource(NonEmpty(form["resource"]), out string? tokenResource);
    if (resourceError != null || (tokenResource != null && session.Resource != null && tokenResource != session.Resource))
    {
        return TokenError("invalid_target", resourceError ?? "resource does not match the authorization request");
    }

    // The nonce (if the client sent one at /authorize) only ever goes into this first id_token, not into refreshed ones.
    return await IssueTokensAsync(context, session, familyId, DateTimeOffset.UtcNow, null, tokenResource, session.Nonce);
}

// Refresh grant (RFC 6749 section 6). Each refresh token works once: using it returns a new one in the same family.
// Presenting one that was already used means it leaked, so the whole family is revoked (the OAuth security BCP's advice, and what Okta does).
async Task<IResult> ExchangeRefreshTokenAsync(HttpContext context, IFormCollection form)
{
    string presented = form["refresh_token"].ToString();
    string? clientId = NullIfEmpty(form["client_id"].ToString());
    string? requestedScope = NullIfEmpty(form["scope"].ToString());

    if (presented == "" || clientId == null)
    {
        return TokenError("invalid_request", "refresh_token and client_id are required");
    }

    // One message for every way a refresh token can be unusable, so a caller learns nothing about which tokens exist
    IResult invalid = TokenError("invalid_grant", "The refresh token is invalid, expired or revoked");

    var record = await refreshStore.FindAsync(presented);
    if (record == null || record.ExpiresAt <= DateTimeOffset.UtcNow || record.Session.ClientId != clientId)
    {
        return invalid;
    }

    if (record.Used)
    {
        await refreshStore.RevokeFamilyAsync(record.FamilyId);
        app.Logger.LogWarning("Refresh token reuse detected for {Account}: revoked all refresh tokens from that sign-in", record.Session.Account);
        return invalid;
    }

    // A refresh may ask for fewer scopes than were granted, never more
    if (requestedScope != null && !SplitScopes(requestedScope).All(SplitScopes(record.Session.Scope).Contains))
    {
        return TokenError("invalid_scope", "The requested scope exceeds the scope originally granted");
    }

    var resourceError = ResolveResource(NonEmpty(form["resource"]), out string? tokenResource);
    if (resourceError != null || (tokenResource != null && record.Session.Resource != null && tokenResource != record.Session.Resource))
    {
        return TokenError("invalid_target", resourceError ?? "resource does not match the original authorization");
    }

    // Only one request can flip the token to used. Losing that race looks exactly like a replay, so it is treated as one.
    if (!await refreshStore.TryMarkUsedAsync(presented))
    {
        await refreshStore.RevokeFamilyAsync(record.FamilyId);
        app.Logger.LogWarning("Refresh token used twice at once for {Account}: revoked all refresh tokens from that sign-in", record.Session.Account);
        return invalid;
    }

    var current = await ReevaluateSessionAsync(record.Session);
    if (current == null)
    {
        await refreshStore.RevokeFamilyAsync(record.FamilyId);
        return invalid;
    }

    return await IssueTokensAsync(context, current, record.FamilyId, record.FamilyCreatedAt, requestedScope, tokenResource, null);
}

// Persona mode re-reads the user and the current role mappings at every refresh, so a role edit or a removed user takes effect without a new sign-in.
// Windows modes cannot re-read group membership without the user's browser sign-in, so the roles from sign-in are kept until they sign in again.
async Task<AuthFlowSession?> ReevaluateSessionAsync(AuthFlowSession session)
{
    if (windowsMode)
    {
        return session;
    }

    var persona = idp.Personas.FirstOrDefault(p => p.Sid == session.Subject);
    if (persona == null)
    {
        return null;
    }

    return session with
    {
        Account = persona.Email,
        Name = persona.Name,
        Roles = IdpUsers.ResolveRoles(IdpUsers.FromPersona(persona), await roleMappings.SnapshotAsync())
    };
}

// Builds the token response for either grant
async Task<IResult> IssueTokensAsync(HttpContext context, AuthFlowSession session, string familyId, DateTimeOffset familyCreatedAt, string? narrowedScope, string? tokenResource, string? nonce)
{
    string issuer = IssuerFor(context.Request);
    var signingKey = await keys.GetActiveAsync();

    // The access token is audience-bound to the protected resource the client asked for (RFC 8707); with no resource it falls back to the client
    string audience = session.Resource ?? tokenResource ?? session.ClientId;

    // offline_access only asks for a refresh token. Like Entra ID, keep it out of the access token's own scope list.
    string[] granted = SplitScopes(narrowedScope ?? session.Scope);
    string[] apiScopes = granted.Where(s => s != "offline_access").ToArray();

    // Windows sign-in maps to Entra's "wia" (Windows Integrated Authentication) amr value; Persona's password form maps to "pwd".
    string[] amr = windowsMode ? new[] { "wia" } : new[] { "pwd" };

    var accessTokenClaims = new Dictionary<string, object> { ["azp"] = session.ClientId, ["azpacr"] = "0" };
    if (apiScopes.Length > 0)
    {
        accessTokenClaims["scp"] = string.Join(' ', apiScopes);
    }
    string accessToken = GenerateJwtToken(signingKey, issuer, audience, session, familyId, null, amr, accessTokenClaims);

    // The id_token is for the client itself, so its audience is always the client_id. amr/azp/scp are access-token-only
    // in Entra ID's own token shape, but nonce (when the client sent one) only ever goes on the id_token.
    string idToken = GenerateJwtToken(signingKey, issuer, session.ClientId, session, familyId, nonce, null);

    var response = new Dictionary<string, object>
    {
        ["access_token"] = accessToken,
        ["token_type"] = "Bearer",
        ["expires_in"] = accessTokenSeconds,
        ["id_token"] = idToken
    };
    if (granted.Length > 0)
    {
        response["scope"] = string.Join(' ', granted);
    }

    // As with Entra ID and Okta, a refresh token is only issued when the client asked for the offline_access scope
    if (SplitScopes(session.Scope).Contains("offline_access"))
    {
        // An opaque random string: the client cannot read it, and only this IdP knows what it stands for.
        // Its lifetime slides (every refresh hands out a new one), but never past the cap counted from the original sign-in.
        string refreshToken = "rt_" + Base64Url.Encode(RandomNumberGenerator.GetBytes(32));
        var now = DateTimeOffset.UtcNow;
        var expiresAt = Earlier(now.AddSeconds(refreshTokenSeconds), familyCreatedAt.AddSeconds(refreshTokenMaxSeconds));
        await refreshStore.SaveAsync(refreshToken, session, familyId, familyCreatedAt, expiresAt);
        response["refresh_token"] = refreshToken;
    }

    return Results.Json(response);
}

DateTimeOffset Earlier(DateTimeOffset a, DateTimeOffset b) => a < b ? a : b;

// Token revocation (RFC 7009). A public client hands back a refresh token it no longer wants, or suspects has leaked,
// and every refresh token from that sign-in stops working. Access tokens are self-contained and simply expire.
app.MapPost("/revoke", async (HttpContext context) =>
{
    context.Response.Headers.CacheControl = "no-store";

    var form = await context.Request.ReadFormAsync();
    string token = form["token"].ToString();
    string? clientId = NullIfEmpty(form["client_id"].ToString());
    string hint = form["token_type_hint"].ToString();

    if (clientId == null || await clients.FindAsync(clientId) == null)
    {
        return Results.Json(new { error = "invalid_client", error_description = "Unknown client_id" }, statusCode: StatusCodes.Status400BadRequest);
    }

    if (token == "")
    {
        return TokenError("invalid_request", "token is required");
    }

    if (hint == "access_token" || token.Count(c => c == '.') == 2)
    {
        return TokenError("unsupported_token_type", "Only refresh tokens can be revoked. An access token stops working when it expires.");
    }

    // Unknown, expired, already revoked, or issued to another client: all answered the same way, so nothing is revealed
    var record = await refreshStore.FindAsync(token);
    if (record != null && record.Session.ClientId == clientId)
    {
        await refreshStore.RevokeFamilyAsync(record.FamilyId);
        app.Logger.LogInformation("Refresh token revoked by client {Client} for {Account}", clientId, record.Session.Account);
    }

    return Results.Ok();
});

// Logout (OpenID Connect RP-Initiated Logout). The client sends the id_token it received. Its sid claim names the sign-in to end.
app.MapMethods("/logout", new[] { "GET", "POST" }, async (HttpContext context) =>
{
    var form = context.Request.HasFormContentType ? await context.Request.ReadFormAsync() : null;
    string? Param(string name)
    {
        string value = context.Request.Query[name].ToString();
        if (value == "" && form != null)
        {
            value = form[name].ToString();
        }
        return NullIfEmpty(value);
    }

    string? hint = Param("id_token_hint");
    string? requestedClient = Param("client_id");
    string? postLogoutUri = Param("post_logout_redirect_uri");
    string? state = Param("state");

    // Without a valid hint nobody can be identified, so nothing is ended and nobody is redirected
    var hinted = hint == null ? null : await ValidateIdTokenHintAsync(context.Request, hint);
    if (hinted == null || (requestedClient != null && requestedClient != hinted.ClientId))
    {
        return SignedOutPage();
    }

    await refreshStore.RevokeFamilyAsync(hinted.Sid);
    app.Logger.LogInformation("Logout: ended sign-in {Sid} for client {Client}", hinted.Sid, hinted.ClientId);

    // Only a redirect address registered for this client is honoured, or the endpoint could be used to bounce people to any site
    var client = await clients.FindAsync(hinted.ClientId);
    if (postLogoutUri != null && client != null && client.PostLogoutRedirectUris.Contains(postLogoutUri))
    {
        return Results.Redirect(state == null ? postLogoutUri : QueryHelpers.AddQueryString(postLogoutUri, "state", state));
    }

    return SignedOutPage();
});

IResult SignedOutPage() => Results.Content(Ui.CenteredPage("Signed out", $@"
        <h2>Signed out</h2>
        <p>You have signed out of the identity provider.</p>
        {(windowsMode ? "<p class='muted'>This IdP signs you in with your Windows account, so opening an application again may sign you straight back in.</p>" : "")}"),
    "text/html; charset=utf-8");

// Checks an id_token the IdP issued: its signature (against its own keys), issuer and audience. Expiry is deliberately ignored,
// because a client logging out is often holding an id_token that has already expired.
async Task<LogoutHint?> ValidateIdTokenHintAsync(HttpRequest request, string token)
{
    var parts = token.Split('.');
    if (parts.Length != 3)
    {
        return null;
    }

    try
    {
        using var header = JsonDocument.Parse(Base64Url.Decode(parts[0]));
        if (header.RootElement.GetProperty("alg").GetString() != "RS256")
        {
            return null;
        }

        string? kid = header.RootElement.TryGetProperty("kid", out var kidElement) ? kidElement.GetString() : null;
        var rsa = kid == null ? null : await keys.GetVerificationKeyAsync(kid);
        if (rsa == null || !rsa.VerifyData(Encoding.UTF8.GetBytes($"{parts[0]}.{parts[1]}"), Base64Url.Decode(parts[2]), HashAlgorithmName.SHA256, RSASignaturePadding.Pkcs1))
        {
            return null;
        }

        using var payload = JsonDocument.Parse(Base64Url.Decode(parts[1]));
        var root = payload.RootElement;

        // An access token also has an sid, but it is not meant for this, so only id_tokens (which have no azp claim) are accepted
        if (root.TryGetProperty("azp", out _) || root.GetProperty("iss").GetString() != IssuerFor(request))
        {
            return null;
        }

        string? audience = root.GetProperty("aud").ValueKind == JsonValueKind.String ? root.GetProperty("aud").GetString() : null;
        string? sid = root.TryGetProperty("sid", out var sidElement) ? sidElement.GetString() : null;
        if (audience == null || sid == null || await clients.FindAsync(audience) == null)
        {
            return null;
        }

        return new LogoutHint(audience, sid);
    }
    catch (Exception ex) when (ex is FormatException or JsonException or KeyNotFoundException or InvalidOperationException or CryptographicException)
    {
        return null;
    }
}

// 5. Admin page: shows the roles the IdP returns for users, lets an administrator edit the group-to-role mappings,
// and end a user's sign-ins
async Task<(IdpUser? User, IResult? Stop)> AdminSignInAsync(HttpContext ctx)
{
    if (!idp.EnableAdminUi)
    {
        return (null, Results.NotFound());
    }

    if (!windowsMode)
    {
        return (null, null);
    }

    var user = await AuthenticateWindowsAsync(ctx);
    return user == null ? (null, ChallengeWindows()) : (user, null);
}

// Persona mode is a development convenience, so anyone using it may edit. Windows mode needs membership in AdminGroup.
bool CanEdit(IdpUser? windowsUser) =>
    !windowsMode || (windowsUser != null && !string.IsNullOrWhiteSpace(idp.AdminGroup) && windowsUser.IsInGroup(idp.AdminGroup));

async Task<List<UserReport>> BuildReportsAsync(IdpUser? windowsUser)
{
    var mappings = await roleMappings.SnapshotAsync();
    var users = windowsMode ? new List<IdpUser> { windowsUser! } : idp.Personas.Select(IdpUsers.FromPersona).ToList();
    return users.Select(u => IdpUsers.Report(u, mappings)).ToList();
}

// Other people's sign-ins are only shown to someone who could end them
async Task<IReadOnlyList<ActiveSession>?> SessionsForAsync(IdpUser? windowsUser) =>
    CanEdit(windowsUser) ? await refreshStore.ListActiveSessionsAsync() : null;

app.MapGet("/admin/roles", async (HttpContext ctx, IAntiforgery antiforgery, string? notice) =>
{
    var (user, stop) = await AdminSignInAsync(ctx);
    if (stop != null)
    {
        return stop;
    }

    var html = AdminPage.Render(ctx.Request.PathBase, idp.AuthenticationMode, await BuildReportsAsync(user), await roleMappings.SnapshotAsync(), await SessionsForAsync(user),
        CanEdit(user), idp.AdminGroup, antiforgery.GetAndStoreTokens(ctx), notice, staticClients.All, await clients.ListAsync());
    return Results.Content(html, "text/html; charset=utf-8");
});

app.MapGet("/admin/roles.json", async (HttpContext ctx) =>
{
    var (user, stop) = await AdminSignInAsync(ctx);
    if (stop != null)
    {
        return stop;
    }

    return Results.Json(new
    {
        mode = idp.AuthenticationMode.ToString(),
        canEdit = CanEdit(user),
        users = await BuildReportsAsync(user),
        roleMappings = await roleMappings.SnapshotAsync(),
        sessions = await SessionsForAsync(user),
        staticClients = staticClients.All,
        registeredClients = await clients.ListAsync()
    }, indented);
});

// Every admin change goes through here: it must come from an admin, and from our own page (a browser sends Windows credentials by itself)
async Task<IResult> AdminPostAsync(HttpContext ctx, IAntiforgery antiforgery, Func<IFormCollection, IdpUser?, Task<string>> action)
{
    var (user, stop) = await AdminSignInAsync(ctx);
    if (stop != null)
    {
        return stop;
    }

    if (!CanEdit(user))
    {
        return Results.StatusCode(StatusCodes.Status403Forbidden);
    }

    try
    {
        await antiforgery.ValidateRequestAsync(ctx);
    }
    catch (AntiforgeryValidationException)
    {
        return Results.BadRequest(new { error = "invalid_request", error_description = "Missing or invalid anti-forgery token" });
    }

    var form = await ctx.Request.ReadFormAsync();
    string notice = await action(form, user);
    return Results.Redirect($"{ctx.Request.PathBase}/admin/roles?notice=" + Uri.EscapeDataString(notice));
}

async Task<string> EditMappingAsync(IFormCollection form, IdpUser? user, bool add)
{
    var mapping = new RoleMapping { Group = form["group"].ToString().Trim(), Role = form["role"].ToString().Trim() };
    string? error = add ? await roleMappings.AddAsync(mapping) : await roleMappings.RemoveAsync(mapping);

    if (error == null)
    {
        app.Logger.LogInformation("Role mapping {Action} by {Editor}: {Group} -> {Role}", add ? "added" : "removed", user?.Account ?? "persona-mode", mapping.Group, mapping.Role);
    }

    return error ?? (add ? "Mapping added." : "Mapping removed.");
}

async Task<string> RevokeSessionsAsync(IFormCollection form, IdpUser? user)
{
    string subject = form["subject"].ToString();
    if (subject == "")
    {
        return "Choose a user.";
    }

    int ended = await refreshStore.RevokeBySubjectAsync(subject);
    app.Logger.LogInformation("Sessions revoked by {Editor} for {Subject}: {Count} sign-in(s)", user?.Account ?? "persona-mode", subject, ended);
    return $"Ended {ended} sign-in(s). Access tokens already issued keep working for up to {accessTokenSeconds} seconds.";
}

app.MapPost("/admin/roles/mappings", (HttpContext ctx, IAntiforgery antiforgery) =>
    AdminPostAsync(ctx, antiforgery, (form, user) => EditMappingAsync(form, user, add: true)));
app.MapPost("/admin/roles/mappings/delete", (HttpContext ctx, IAntiforgery antiforgery) =>
    AdminPostAsync(ctx, antiforgery, (form, user) => EditMappingAsync(form, user, add: false)));
app.MapPost("/admin/roles/sessions/revoke", (HttpContext ctx, IAntiforgery antiforgery) =>
    AdminPostAsync(ctx, antiforgery, RevokeSessionsAsync));

// Lets an admin register a client as trusted (Dynamic: false, skips the /authorize consent page) without
// editing Idp:Clients + restarting, and remove it again -- mainly so both the silent and consent-required
// paths can be exercised for testing without a redeploy cycle.
async Task<string> RegisterTrustedClientAsync(IFormCollection form, IdpUser? user)
{
    string clientId = form["client_id"].ToString().Trim();
    if (clientId == "")
    {
        clientId = "client_" + Convert.ToHexString(RandomNumberGenerator.GetBytes(8));
    }
    else if (await clients.FindAsync(clientId) != null || staticClients.Find(clientId) != null)
    {
        return $"A client named {clientId} already exists.";
    }

    var redirectUris = form["redirect_uris"].ToString()
        .Split('\n', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)
        .ToList();
    if (redirectUris.Count == 0 || redirectUris.Count > MaxRedirectUris)
    {
        return $"Provide between 1 and {MaxRedirectUris} redirect URIs, one per line.";
    }
    if (redirectUris.Any(uri => uri.Length > MaxUriLength || !IsAcceptableRedirectUri(uri)))
    {
        return "Each redirect URI must be an absolute https URI or an http loopback URI, without a fragment.";
    }

    string? name = NullIfEmpty(form["name"].ToString());
    if (name is { Length: > MaxClientNameLength })
    {
        return $"Name is limited to {MaxClientNameLength} characters.";
    }

    bool ok = await clients.TryRegisterAsync(new ClientInfo(clientId, redirectUris, [], name, Dynamic: false), name, MaxDynamicClients);
    if (!ok)
    {
        return "The limit on registered clients has been reached.";
    }

    app.Logger.LogInformation("Trusted client registered by {Editor}: {ClientId}", user?.Account ?? "persona-mode", clientId);
    return $"Registered trusted client {clientId}. It will not need to be allowed by sign-in users at /authorize.";
}

async Task<string> RemoveClientAsync(IFormCollection form, IdpUser? user)
{
    string clientId = form["client_id"].ToString();
    if (clientId == "")
    {
        return "Choose a client.";
    }

    await clients.RemoveAsync(clientId);
    app.Logger.LogInformation("Client removed by {Editor}: {ClientId}", user?.Account ?? "persona-mode", clientId);
    return $"Removed client {clientId}.";
}

app.MapPost("/admin/roles/clients/register", (HttpContext ctx, IAntiforgery antiforgery) =>
    AdminPostAsync(ctx, antiforgery, RegisterTrustedClientAsync));
app.MapPost("/admin/roles/clients/remove", (HttpContext ctx, IAntiforgery antiforgery) =>
    AdminPostAsync(ctx, antiforgery, RemoveClientAsync));

// Checks an authorization request, at /authorize and again at /login or /authorize/consent (their form fields can be forged).
// Audience is the resource the token will be for, in the form the resource server expects it (null when none was asked for).
async Task<AuthorizationRequestCheck> ValidateAuthorizationRequestAsync(string? clientId, string? redirectUri, string? responseType, string? codeChallenge,
    string? codeChallengeMethod, string[] resources, string? scope)
{
    // Unknown client or unregistered redirect: never redirect back, since that would be an open redirect
    var client = clientId == null ? null : await clients.FindAsync(clientId);
    if (client == null || redirectUri == null || !client.RedirectUris.Contains(redirectUri))
    {
        return new AuthorizationRequestCheck(Results.BadRequest(new { error = "invalid_request", error_description = "Unknown client_id or unregistered redirect_uri" }), null, null, null, null);
    }

    // From here the redirect address is trusted, so a problem is reported to the client by redirecting back with error= (RFC 6749 section 4.1.2.1).
    // A missing response_type is tolerated (MiniOidcClient omits it) but a different one is not.
    AuthorizationRequestCheck Reject(string error, string description) => new(null, error, description, null, client);

    if (responseType != null && responseType != "code")
    {
        return Reject("unsupported_response_type", "response_type must be code");
    }

    if (codeChallenge == null || !pkceChallenge.IsMatch(codeChallenge))
    {
        return Reject("invalid_request", "code_challenge is required and must be an unpadded base64url SHA-256 value (43 characters)");
    }

    if (codeChallengeMethod != "S256")
    {
        return Reject("invalid_request", "code_challenge_method must be S256");
    }

    var resourceError = ResolveResource(resources, out string? audience);
    if (resourceError != null)
    {
        return Reject("invalid_target", resourceError);
    }

    var scopeError = CheckScopes(scope, audience);
    if (scopeError != null)
    {
        return Reject("invalid_scope", scopeError);
    }

    return new AuthorizationRequestCheck(null, null, null, audience, client);
}

// Turns what a failed check holds into the response: an error page, or a redirect back to the client
IResult? Failure(HttpContext context, AuthorizationRequestCheck check, string? redirectUri, string? state) =>
    check.Fatal ?? (check.Error == null ? null : AuthorizationError(context, redirectUri!, state, check.Error, check.Description!));

IResult AuthorizationError(HttpContext context, string redirectUri, string? state, string error, string description)
{
    var parameters = new Dictionary<string, string?> { ["error"] = error, ["error_description"] = description, ["iss"] = IssuerFor(context.Request) };
    if (state != null)
    {
        parameters["state"] = state;
    }

    return Results.Redirect(QueryHelpers.AddQueryString(redirectUri, parameters));
}

string[] NonEmpty(StringValues values) => values.OfType<string>().Where(v => v != "").ToArray();

// Works out which resource a request is for (RFC 8707). Returns an error message when it cannot be used. With resources
// configured, only those are accepted, and the audience is the configured spelling, which is what the resource server expects.
string? ResolveResource(string[] requested, out string? audience)
{
    audience = null;
    if (requested.Length == 0)
    {
        return null;
    }

    if (requested.Length > 1)
    {
        return "Only one resource per request is supported";
    }

    if (!Uri.TryCreate(requested[0], UriKind.Absolute, out var uri) || !string.IsNullOrEmpty(uri.Fragment))
    {
        return "resource must be an absolute URI without a fragment";
    }

    if (!enforceResources)
    {
        audience = requested[0];
        return null;
    }

    if (!registeredResources.TryGetValue(ResourceKey(uri), out var known))
    {
        return "Unknown resource";
    }

    audience = known.Resource;
    return null;
}

// With resources configured, a request may only ask for openid, offline_access and the scopes of the resource it names
string? CheckScopes(string? scope, string? audience)
{
    if (!enforceResources)
    {
        return null;
    }

    var allowed = new HashSet<string>(baseScopes);
    if (audience != null)
    {
        allowed.UnionWith(registeredResources.Values.Where(r => r.Resource == audience).SelectMany(r => r.Scopes));
    }

    string[] rejected = SplitScopes(scope).Where(s => !allowed.Contains(s)).ToArray();
    return rejected.Length == 0 ? null : $"Scope not allowed here: {string.Join(' ', rejected)}";
}

bool IsAcceptableRedirectUri(string? uri)
{
    if (!Uri.TryCreate(uri, UriKind.Absolute, out var parsed) || !string.IsNullOrEmpty(parsed.Fragment))
    {
        return false;
    }

    return parsed.Scheme == Uri.UriSchemeHttps || (parsed.Scheme == Uri.UriSchemeHttp && parsed.IsLoopback);
}

string? NullIfEmpty(string? value) => string.IsNullOrEmpty(value) ? null : value;

// Structural Token Builder. sid ties the token to the sign-in it came from, so a logout can end that sign-in.
// Claim names follow Microsoft Entra ID's v2.0 token shape (see access-token-claims-reference and
// id-token-claims-reference on Microsoft Learn) so code written against this mock needs minimal changes to work
// against a real Entra ID tenant later. amr is access-token-only and nonce is id_token-only, matching that reference.
// oid (here, the user's Subject/SID) is the stable per-user id; sub is deliberately different per client_id, like Entra's.
string GenerateJwtToken(SigningKey key, string issuer, string audience, AuthFlowSession user, string sid, string? nonce, string[]? amr, Dictionary<string, object>? extraClaims = null)
{
    var header = new { alg = "RS256", typ = "JWT", kid = key.Kid };
    var payload = new Dictionary<string, object>
    {
        ["iss"] = issuer,
        ["idp"] = issuer,
        ["uti"] = Guid.NewGuid().ToString("N"), // unique per token; Entra ID's equivalent of the JWT-standard jti
        ["sub"] = Pairwise(user.Subject, user.ClientId),
        ["oid"] = user.Subject,
        ["tid"] = idp.TenantId,
        ["sid"] = sid,
        ["aud"] = audience,
        ["exp"] = DateTimeOffset.UtcNow.AddSeconds(accessTokenSeconds).ToUnixTimeSeconds(),
        ["iat"] = DateTimeOffset.UtcNow.ToUnixTimeSeconds(),
        ["nbf"] = DateTimeOffset.UtcNow.ToUnixTimeSeconds(),
        ["ver"] = "2.0",
        ["name"] = user.Name,
        ["preferred_username"] = user.Account,
        ["roles"] = user.Roles // Injected roles exactly like Azure Entra ID
    };
    if (nonce != null)
    {
        payload["nonce"] = nonce;
    }
    if (amr != null)
    {
        payload["amr"] = amr;
    }
    foreach (var claim in extraClaims ?? new Dictionary<string, object>())
    {
        payload[claim.Key] = claim.Value;
    }

    string encodedHeader = Base64Url.Encode(Encoding.UTF8.GetBytes(JsonSerializer.Serialize(header)));
    string encodedPayload = Base64Url.Encode(Encoding.UTF8.GetBytes(JsonSerializer.Serialize(payload)));

    string stringToSign = $"{encodedHeader}.{encodedPayload}";
    byte[] signatureBytes = key.Rsa.SignData(Encoding.UTF8.GetBytes(stringToSign), HashAlgorithmName.SHA256, RSASignaturePadding.Pkcs1);

    return $"{stringToSign}.{Base64Url.Encode(signatureBytes)}";
}

app.Run();

// The client and sign-in a logout request's id_token_hint points at
record LogoutHint(string ClientId, string Sid);

// The outcome of checking an authorization request. Fatal: the client or redirect address is not trusted, so show an error page.
// Error and Description: the request is unusable but the client is known, so tell it by redirecting back.
record AuthorizationRequestCheck(IResult? Fatal, string? Error, string? Description, string? Audience, ClientInfo? Client);
