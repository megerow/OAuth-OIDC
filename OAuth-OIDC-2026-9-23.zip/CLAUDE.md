# Project context for Claude

OAuth 2.0 / OIDC in .NET 10. `MiniOidcIdp`, deployed to IIS in `WindowsIis` mode, is now used as a real interim identity provider pending a move to Entra ID or Okta; the rest of the repo remains a learning sandbox for the underlying protocol. See [README.md](README.md) for the projects, endpoints, flows and diagrams. This file holds only what isn't obvious from the code.

## Ground rules

- **Add new projects rather than changing existing ones**, unless a change is necessary. (The user asked for this when MiniOidcIdp was added.)
- Most of this remains a mock for learning: in-memory state, plaintext passwords (Persona mode), plain HTTP by default. `MiniOidcIdp` deployed via `WindowsIis` is the exception — real Windows accounts, HTTPS, real AD group role mapping — but it has had no formal security review. Don't let README's [Limitations](README.md#limitations) list go stale as things change.

## Ports and run order

| Project | Port |
|---|---|
| MiniOidcServiceWeb or MiniOidcIdp (run one, not both) | 5121 |
| MiniProtectedApi | 5062 |
| MiniMcpServer | 5046 |
| MiniOidcClient or MiniFlaskClient (callback listener; run one at a time) | 8080 |

Start the identity provider first. MiniProtectedApi and MiniMcpServer read an `Auth` section from `appsettings.json` (`Authority`, `Audience`, `RoleClaimType`, and for MCP also `Resource` and `Scopes`). Override with environment variables such as `Auth__Authority`. Token `iss` follows the request address, so the authority must match how the IdP is reached.

## Habits that saved time

- **Leftover background servers hold ports.** Check with `ss -tlnp | grep -E ':(5121|5062|5046|8080)\b'` and free one with `fuser -k <port>/tcp`. Match the real process name (`MiniOidcService`), not `dotnet`.
- **Free ports with `fuser -k <port>/tcp`, not `pkill -f '<pattern>'`.** Running `pkill -f` from a shell command that contains the pattern kills the calling shell (exit 144).
- **Test on temporary ports** so a running instance isn't disturbed: `dotnet run --no-build --urls http://localhost:5400` with `Auth__Authority=...` set for the API and MCP server, plus `Auth__Audience=...` and `Auth__Resource=...` for the MCP server (its default port 5046 is often already taken by a running instance, which makes a new copy fail to start and hides that in test results).
- The OAuth interop test for the MCP server used the official `ModelContextProtocol` SDK client (`HttpClientTransport` with `ClientOAuthOptions`, dynamic registration, and a redirect delegate that submits the login form). It lived outside the repo and isn't saved here. Rebuild it if needed.
- **Mind line endings when patching files with a script.** `MiniOidcServiceWeb/appsettings.json` uses CRLF. Python's text mode turns it into LF and inflates the git diff, so open with `newline=''` or use the Edit tool. Check with `git diff --stat`.
- **Shorten token lifetimes to watch refresh work.** `Tokens__AccessTokenSeconds=6` on an IdP plus `REFRESH_MARGIN_SECONDS=2` on MiniFlaskClient shows the whole cycle in seconds.
- **`dotnet ef` on this machine:** install it with `dotnet tool install dotnet-ef --version 10.0.12 --tool-path <scratch dir>` (not globally) and run it with `DOTNET_ROOT=$HOME/.dotnet`, or the launcher says the runtime is missing. Migrations are per provider: `--context SqliteIdpDbContext --output-dir Persistence/Migrations/Sqlite`, and the same for `SqlServerIdpDbContext` / `SqlServer`. After a model change, run `dotnet ef migrations has-pending-model-changes --context <ctx>` for both.
- **Testing persistence:** start MiniOidcIdp with `Persistence__Provider=Sqlite`, `Persistence__ConnectionString="Data Source=<file>"` and `Persistence__EncryptionKey=$(openssl rand -base64 32)`. Two processes on different ports with the same file simulate two servers, which is how the race, shared-key and cross-node checks were done. The test scripts lived in the scratchpad and are not saved here.
- Mermaid diagrams in the README can be parse-checked with the `mermaid` npm package and rendered with `@mermaid-js/mermaid-cli` using the system Chrome.

## Status and open items

- Refresh tokens: both IdPs issue them when `offline_access` is requested (opaque, rotated on every use, replay revokes the family, 24 hour sliding lifetime), and MiniFlaskClient uses them. MiniOidcClient and the MCP test client do not. In MiniOidcIdp Windows modes, roles from sign-in are kept across refreshes because groups can't be re-read without a browser sign-in (untested).
- MiniOidcIdp only: optional SQLite / SQL Server persistence (`Persistence:Provider`), `POST /revoke`, `/logout` with the `sid` claim, an absolute refresh cap (`Tokens:RefreshTokenMaxSeconds`), admin "End sign-ins", fixed issuer (`Idp:Issuer`), and a switch for `/register`. **SQLite is tested, including two processes sharing one file. The SQL Server provider is only compiled and its generated script reviewed, never run.** Access tokens are not revoked (no introspection).
- Not built: refresh replay grace period, token introspection, login rate limiting, encryption-key rotation, logout notifications to other applications.
- MiniOidcIdp: `Persona` mode is tested. `WindowsKestrel` mode has been run and verified against a real Active Directory account (roles resolved from real group membership). `WindowsIis` mode is deployed to a real IIS server and in use as the interim identity provider — see README's [Deploying MiniOidcIdp to IIS](README.md#deploying-minioidcidp-to-iis) for the configuration and the IIS-specific issues found so far (anonymous-auth scoping, config surviving a republish, app-pool file permissions).
- Claude Code authenticating to MiniMcpServer through its own OAuth flow has **not been tried**. Only the SDK client has.
- MiniOidcClient sends the `id_token` to MiniProtectedApi, which is a shortcut. The proper change is to send the `access_token` and give the API its own audience. Not done because it touches two existing projects.
- Ideas raised but not built: a `MiniMcpClient` project, a token-exchange endpoint for service-to-service calls, and a persistent signing key.

## Moving to another machine

Conversation history is not in the repo. See [docs/MOVING-CLAUDE-HISTORY.md](docs/MOVING-CLAUDE-HISTORY.md).
