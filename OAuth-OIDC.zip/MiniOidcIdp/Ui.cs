using System.Net;

// The look shared by every page the IdP renders (login, consent, signed-out, admin). It follows the Innovation Solutions suite
// (the ChatClient app): dark-teal sidebar and top bar, grey page, white cards, #1b6ec2 buttons, black table headers.
// Everything is inline and self-contained on purpose. A sign-in page must not depend on a CDN, and a stricter
// Content-Security-Policy later only has to allow this one stylesheet.
static class Ui
{
    public const string Product = "Identity Provider";

    public static string Html(string? s) => WebUtility.HtmlEncode(s ?? "");

    // The canopy icon from the suite, drawn white (it sits on the teal bar)
    const string Logo = "<svg class='logo' viewBox='0 0 280.8 280.8' width='22' height='22' aria-hidden='true'>" +
        "<path d='M263.7,159.5H74.3c-9.5,0-17.1-7.7-17.1-17.1s7.7-17.1,17.1-17.1h172.3v-1.8l-104.4-84.5L34.2,122.9v19.5c0,9.5-7.7,17.1-17.1,17.1S0,151.8,0,142.4v-27.8c0-5.3,2.4-10.3,6.6-13.5L131.8,3.6c6.3-4.9,15.1-4.8,21.3.2l121.3,98.2c4,3.3,6.4,8.1,6.4,13.3v27.1c0,9.5-7.7,17.1-17.1,17.1Z'/>" +
        "<path d='M263.7,280.8c-9.5,0-17.1-7.7-17.1-17.1v-67.7c0-9.5,7.7-17.1,17.1-17.1s17.1,7.7,17.1,17.1v67.7c0,9.5-7.7,17.1-17.1,17.1Z'/>" +
        "<path d='M17.1,280.8c-9.5,0-17.1-7.7-17.1-17.1v-67.7c0-9.5,7.7-17.1,17.1-17.1s17.1,7.7,17.1,17.1v67.7c0,9.5-7.7,17.1-17.1,17.1Z'/>" +
        "<circle cx='78' cy='229.8' r='21.6'/><circle cx='202.8' cy='229.8' r='21.6'/><circle cx='140.4' cy='229.8' r='21.6'/></svg>";

    const string Css = """
        :root { --teal:#003d4d; --teal-text:#e8eaed; --page:#e9e9e9; --accent:#1b6ec2; --accent-border:#1861ac; --focus:#6ab2c0; --link:#0077cc;
                --font:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,system-ui,sans-serif; }
        html { font-size:14px; }
        @media (min-width:768px) { html { font-size:16px; } }
        body { margin:0; font-family:var(--font); background:var(--page); color:#212529; line-height:1.5; }
        a { color:var(--link); }
        h1,h2,h3 { color:var(--teal); line-height:1.25; margin:0 0 .6rem; }
        h1 { font-size:1.6rem; } h2 { font-size:1.25rem; } h3 { font-size:1.05rem; }
        .logo path,.logo circle { fill:#fff; }
        .brand { display:flex; align-items:center; gap:.55rem; font-weight:700; font-size:1.35rem; }
        .ws { letter-spacing:2px; font-size:.75rem; text-transform:uppercase; }

        /* Single-card pages: sign in, consent, signed out */
        .topbar { display:flex; justify-content:space-between; align-items:center; background:var(--teal); color:#fff; padding:.8rem 1.25rem; }
        .center { max-width:30rem; margin:2.5rem auto; padding:0 1rem; }

        /* Sidebar pages: admin */
        .shell { display:flex; min-height:100vh; }
        .sidebar { width:260px; flex-shrink:0; background:var(--teal); color:var(--teal-text); display:flex; flex-direction:column; }
        .sidebar .brand { padding:1.1rem 1.25rem .15rem; color:#fff; }
        .sidebar .ws { padding:0 1.25rem 1rem; color:rgba(232,234,237,.55); border-bottom:1px solid rgba(255,255,255,.08); }
        .sidebar nav a { display:block; padding:.65rem 1.25rem; color:var(--teal-text); text-decoration:none; }
        .sidebar nav a:hover,.sidebar nav a.active { background:rgba(255,255,255,.14); }
        .user-chip { margin-top:auto; padding:1rem 1.25rem; border-top:1px solid rgba(255,255,255,.08); font-size:.9rem; overflow-wrap:anywhere; }
        .main { flex:1; min-width:0; padding:1.5rem; }
        @media (max-width:767.98px) {
          .shell { flex-direction:column; }
          .sidebar { width:auto; flex-direction:row; flex-wrap:wrap; align-items:center; }
          .sidebar .brand { padding:.7rem 1rem; } .sidebar .ws { display:none; }
          .sidebar nav { display:flex; } .sidebar nav a { padding:.7rem .8rem; }
          .user-chip { margin:0 0 0 auto; border:0; padding:.7rem 1rem; }
          .main { padding:.85rem; }
        }

        .card { background:#fff; border:1px solid #dee2e6; border-radius:.75rem; padding:1.25rem 1.5rem; margin-bottom:1rem; }
        .card > :first-child { margin-top:0; }
        table { border-collapse:collapse; width:100%; margin:.5rem 0 1rem; font-size:.95rem; }
        th,td { border:1px solid #dee2e6; padding:.4rem .6rem; text-align:left; vertical-align:top; }
        th { background:#000; color:#fff; font-weight:600; }
        table.kv th { background:#f1f3f5; color:#212529; width:30%; }
        code { font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace; font-size:.9em; background:#f1f3f5; border-radius:.25rem; padding:.1rem .3rem; }
        .role { display:inline-block; background:var(--accent); color:#fff; border-radius:999px; padding:.05rem .65rem; margin:0 .25rem .15rem 0; font-size:.9rem; }
        .muted { color:#6c757d; } .yes { color:#198754; font-weight:600; }
        code:empty { display:none; }
        small { color:#6c757d; }

        .alert { border-radius:.5rem; padding:.6rem .9rem; margin:0 0 1rem; border:1px solid; }
        .alert-info { background:#fff3cd; color:#664d03; border-color:#ffe69c; }
        .alert-error { background:#f8d7da; color:#842029; border-color:#f5c2c7; }

        label { display:block; font-weight:600; margin-bottom:.25rem; }
        input[type=text],input[type=email],input[type=password] { box-sizing:border-box; width:100%; padding:.45rem .65rem; font:inherit; border:1px solid #ced4da; border-radius:.4rem; background:#fff; }
        input:focus,button:focus-visible { outline:0; border-color:var(--focus); box-shadow:0 0 0 .25rem rgba(106,178,192,.4); }
        .field { margin-bottom:1rem; }
        form.inline { display:inline; }
        .btn { display:inline-block; padding:.45rem 1rem; font:inherit; font-weight:600; color:#fff; background:var(--accent); border:1px solid var(--accent-border); border-radius:.4rem; cursor:pointer; text-decoration:none; }
        .btn:hover { background:var(--accent-border); }
        .btn-block { width:100%; }
        .btn-secondary { background:#fff; color:#495057; border-color:#ced4da; }
        .btn-secondary:hover { background:#f1f3f5; }
        .btn-sm { padding:.2rem .6rem; font-size:.9rem; }
        """;

    static string Head(string title) =>
        $"<!DOCTYPE html><html lang='en'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width, initial-scale=1'><title>{Html(title)}</title><style>{Css}</style></head>";

    // A single white card under the top bar: sign in, consent, signed out
    public static string CenteredPage(string title, string body) =>
        Head($"{Product} - {title}") +
        $"<body><header class='topbar'><div class='brand'>{Logo}<span>{Product}</span></div><div class='ws'>Wilson Sonsini</div></header>" +
        $"<main class='center'><div class='card'>{body}</div></main></body></html>";

    // Sidebar with links and a user chip, and a grey main pane that holds cards: the admin page
    public static string SidebarPage(string title, string navLinks, string chip, string main) =>
        Head($"{Product} - {title}") +
        $"<body><div class='shell'><aside class='sidebar'><div class='brand'>{Logo}<span>{Product}</span></div><div class='ws'>Wilson Sonsini</div>" +
        $"<nav>{navLinks}</nav><div class='user-chip'>{chip}</div></aside><main class='main'>{main}</main></div></body></html>";
}
