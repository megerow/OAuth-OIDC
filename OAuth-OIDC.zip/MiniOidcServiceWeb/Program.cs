using System.Collections.Concurrent;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.WebUtilities;

var builder = WebApplication.CreateBuilder(args);
var app = builder.Build();

// 1. Core State
using RSA rsaKey = RSA.Create(2048);

// Key ID derived from the public key, so a restart (new key) never reuses a stale kid
var publicParams = rsaKey.ExportParameters(false);
string kid = Base64UrlEncode(SHA256.HashData(publicParams.Modulus!))[..16];

string IssuerFor(HttpRequest r) => $"{r.Scheme}://{r.Host}";
string Html(string? s) => WebUtility.HtmlEncode(s ?? "");

// A fixed mock tenant, the same for every user, mirroring Entra ID's tid claim
const string TenantId = "a1b2c3d4-e5f6-4a1b-8c2d-1a2b3c4d5e6f";

// Active login flows in progress (maps: temporary auth_code -> session details)
var activeFlows = new ConcurrentDictionary<string, AuthFlowSession>();

// Refresh tokens live only here, keyed by the opaque token string. Used tokens stay until they expire so a replay can be recognised.
var refreshTokens = new ConcurrentDictionary<string, RefreshRecord>();
object refreshLock = new();

int accessTokenSeconds = Math.Max(1, app.Configuration.GetValue<int>("Tokens:AccessTokenSeconds", 3600));
int refreshTokenSeconds = Math.Max(1, app.Configuration.GetValue<int>("Tokens:RefreshTokenSeconds", 86400));

// Registered clients (static + dynamically registered via /register): client_id -> exact redirect URIs allowed
var registeredClients = new ConcurrentDictionary<string, HashSet<string>>
{
    ["my_learning_client_app"] = new() { "http://localhost:8080/callback/" }
};

// Mock User Database with Roles
var mockUserDatabase = new Dictionary<string, (string Password, string Name, string[] Roles)>
{
    { "jane.doe@example.com", ("password123", "Jane Doe", new[] { "Admin", "BillingManager" }) },
    { "john.smith@example.com", ("password123", "John Smith", new[] { "BillingManager" }) }
};

// Authorization server metadata, served both as OIDC discovery and as RFC 8414 metadata (MCP clients look for either)
object ServerMetadata(string issuer) => new
{
    issuer,
    authorization_endpoint = $"{issuer}/authorize",
    token_endpoint = $"{issuer}/token",
    jwks_uri = $"{issuer}/.well-known/jwks.json",
    registration_endpoint = $"{issuer}/register",
    response_types_supported = new[] { "code" },
    grant_types_supported = new[] { "authorization_code", "refresh_token" },
    subject_types_supported = new[] { "public" },
    id_token_signing_alg_values_supported = new[] { "RS256" },
    code_challenge_methods_supported = new[] { "S256" },
    token_endpoint_auth_methods_supported = new[] { "none" },
    scopes_supported = new[] { "openid", "offline_access", "mcp:tools" }
};

app.MapGet("/.well-known/openid-configuration", (HttpRequest request) => Results.Json(ServerMetadata(IssuerFor(request))));
app.MapGet("/.well-known/oauth-authorization-server", (HttpRequest request) => Results.Json(ServerMetadata(IssuerFor(request))));

// Public signing key (JWK) used to verify the RS256 signature on issued tokens
app.MapGet("/.well-known/jwks.json", () => Results.Json(new
{
    keys = new[]
    {
        new
        {
            kty = "RSA",
            use = "sig",
            alg = "RS256",
            kid,
            n = Base64UrlEncode(publicParams.Modulus!),
            e = Base64UrlEncode(publicParams.Exponent!)
        }
    }
}));

// Dynamic Client Registration (RFC 7591): public clients register their redirect URIs and receive a client_id
app.MapPost("/register", async (HttpContext context) =>
{
    JsonElement body;
    try
    {
        body = (await JsonDocument.ParseAsync(context.Request.Body)).RootElement;
    }
    catch (JsonException)
    {
        return Results.Json(new { error = "invalid_client_metadata", error_description = "Body must be JSON" }, statusCode: 400);
    }

    if (body.ValueKind != JsonValueKind.Object ||
        !body.TryGetProperty("redirect_uris", out var uris) || uris.ValueKind != JsonValueKind.Array || uris.GetArrayLength() == 0)
    {
        return Results.Json(new { error = "invalid_redirect_uri", error_description = "redirect_uris is required" }, statusCode: 400);
    }

    var redirectUris = new HashSet<string>();
    foreach (var element in uris.EnumerateArray())
    {
        string? uri = element.ValueKind == JsonValueKind.String ? element.GetString() : null;
        if (!IsAcceptableRedirectUri(uri))
        {
            return Results.Json(new { error = "invalid_redirect_uri", error_description = "Redirect URIs must be absolute https URIs or http loopback URIs, without fragments" }, statusCode: 400);
        }
        redirectUris.Add(uri!);
    }

    string clientId = "client_" + Convert.ToHexString(RandomNumberGenerator.GetBytes(8));
    registeredClients[clientId] = redirectUris;

    string? clientName = body.TryGetProperty("client_name", out var nameElement) && nameElement.ValueKind == JsonValueKind.String ? nameElement.GetString() : null;

    return Results.Json(new
    {
        client_id = clientId,
        client_id_issued_at = DateTimeOffset.UtcNow.ToUnixTimeSeconds(),
        client_name = clientName,
        redirect_uris = redirectUris,
        token_endpoint_auth_method = "none",
        grant_types = new[] { "authorization_code", "refresh_token" },
        response_types = new[] { "code" }
    }, statusCode: 201);
});

// 2. Endpoint: The Initial OIDC Redirection Trigger (Step 1 & 2 of the Flow)
app.MapGet("/authorize", ([FromQuery] string client_id, [FromQuery] string redirect_uri, [FromQuery] string code_challenge, [FromQuery] string code_challenge_method,
    [FromQuery] string? resource, [FromQuery] string? scope, [FromQuery] string? state, [FromQuery] string? nonce) =>
{
    var error = ValidateAuthorizationRequest(client_id, redirect_uri, code_challenge_method, resource);
    if (error != null)
    {
        return error;
    }

    // Prefilled with the demo user so a first-time visitor can just click the button
    return LoginForm(client_id, redirect_uri, code_challenge, code_challenge_method, resource, scope, state, nonce, "jane.doe@example.com", "password123", null);
});

// A lightweight, raw HTML login/consent form. It is also shown again, with an error, when a sign-in fails.
IResult LoginForm(string clientId, string redirectUri, string codeChallenge, string codeChallengeMethod, string? resource, string? scope, string? state, string? nonce, string email, string password, string? errorMessage)
{
    string errorHtml = errorMessage == null
        ? ""
        : $"<p role='alert' class='alert'>{Html(errorMessage)}</p>";

    // Same look as the other Innovation Solutions apps (dark-teal bar, grey page, white card). Inline, so no CDN is needed.
    var html = $@"<!DOCTYPE html>
        <html lang='en'>
        <head>
            <meta charset='utf-8'><meta name='viewport' content='width=device-width, initial-scale=1'><title>Identity Provider - Sign in</title>
            <style>
                :root {{ --teal:#003d4d; --accent:#1b6ec2; --accent-border:#1861ac; --focus:#6ab2c0; }}
                html {{ font-size:14px; }} @media (min-width:768px) {{ html {{ font-size:16px; }} }}
                body {{ margin:0; font-family:-apple-system,BlinkMacSystemFont,""Segoe UI"",Roboto,system-ui,sans-serif; background:#e9e9e9; color:#212529; line-height:1.5; }}
                .topbar {{ display:flex; justify-content:space-between; align-items:center; background:var(--teal); color:#fff; padding:.8rem 1.25rem; }}
                .brand {{ font-weight:700; font-size:1.35rem; }} .ws {{ letter-spacing:2px; font-size:.75rem; text-transform:uppercase; }}
                .card {{ max-width:28rem; margin:2.5rem auto; background:#fff; border:1px solid #dee2e6; border-radius:.75rem; padding:1.25rem 1.5rem; }}
                h2 {{ color:var(--teal); margin:0 0 .6rem; }}
                label {{ display:block; font-weight:600; margin-bottom:.25rem; }} .field {{ margin-bottom:1rem; }}
                input[type=email], input[type=password] {{ box-sizing:border-box; width:100%; padding:.45rem .65rem; font:inherit; border:1px solid #ced4da; border-radius:.4rem; }}
                input:focus, button:focus-visible {{ outline:0; border-color:var(--focus); box-shadow:0 0 0 .25rem rgba(106,178,192,.4); }}
                button {{ width:100%; padding:.5rem 1rem; font:inherit; font-weight:600; color:#fff; background:var(--accent); border:1px solid var(--accent-border); border-radius:.4rem; cursor:pointer; }}
                button:hover {{ background:var(--accent-border); }}
                .alert {{ background:#f8d7da; color:#842029; border:1px solid #f5c2c7; border-radius:.5rem; padding:.6rem .9rem; }}
            </style>
        </head>
        <body>
            <header class='topbar'><div class='brand'>Identity Provider</div><div class='ws'>Wilson Sonsini</div></header>
            <main class='card'>
            <h2>Sign in</h2>
            {errorHtml}
            <form action='/login' method='POST'>
                <!-- Pass along the client parameters hidden so the form submission keeps context -->
                <input type='hidden' name='client_id' value='{Html(clientId)}' />
                <input type='hidden' name='redirect_uri' value='{Html(redirectUri)}' />
                <input type='hidden' name='code_challenge' value='{Html(codeChallenge)}' />
                <input type='hidden' name='code_challenge_method' value='{Html(codeChallengeMethod)}' />
                <input type='hidden' name='resource' value='{Html(resource)}' />
                <input type='hidden' name='scope' value='{Html(scope)}' />
                <input type='hidden' name='state' value='{Html(state)}' />
                <input type='hidden' name='nonce' value='{Html(nonce)}' />

                <div class='field'>
                    <label for='email'>Email</label>
                    <input type='email' id='email' name='email' value='{Html(email)}' required />
                </div>
                <div class='field'>
                    <label for='password'>Password</label>
                    <input type='password' id='password' name='password' value='{Html(password)}' required />
                </div>
                <button type='submit'>Sign In &amp; Grant Consent</button>
            </form>
            </main>
        </body>
        </html>";

    return Results.Content(html, "text/html; charset=utf-8");
}

// 3. Endpoint: Form Post-Back Process (Step 3 & 4 of the Flow)
app.MapPost("/login", async (HttpContext context) =>
{
    var form = await context.Request.ReadFormAsync();
    string email = form["email"].ToString();
    string password = form["password"].ToString();
    string clientId = form["client_id"].ToString();
    string redirectUri = form["redirect_uri"].ToString();
    string codeChallenge = form["code_challenge"].ToString();
    string? resource = NullIfEmpty(form["resource"].ToString());
    string? scope = NullIfEmpty(form["scope"].ToString());
    string? state = NullIfEmpty(form["state"].ToString());
    string? nonce = NullIfEmpty(form["nonce"].ToString());

    // The form fields are attacker-controllable, so the request is validated again here, not just at /authorize
    var error = ValidateAuthorizationRequest(clientId, redirectUri, form["code_challenge_method"].ToString(), resource);
    if (error != null || string.IsNullOrEmpty(codeChallenge))
    {
        return error ?? Results.BadRequest(new { error = "invalid_request", error_description = "code_challenge is required" });
    }

    // Validate Credentials. A wrong password shows the form again with a generic message (no hint about which part was wrong)
    // and keeps the request details, so the user can retry. The password is never echoed back.
    if (!mockUserDatabase.TryGetValue(email, out var userRecord) || userRecord.Password != password)
    {
        return LoginForm(clientId, redirectUri, codeChallenge, form["code_challenge_method"].ToString(), resource, scope, state, nonce, email, "", "Incorrect email or password.");
    }

    // Generate a secure, randomized one-time authorization code
    string authorizationCode = "auth_" + Convert.ToHexString(RandomNumberGenerator.GetBytes(16));

    // Save the workflow data in memory to match up during the subsequent /token exchange
    activeFlows[authorizationCode] = new AuthFlowSession(clientId, redirectUri, codeChallenge, email, userRecord.Name, userRecord.Roles, resource, scope, nonce);

    // Redirect the browser window straight back to the client application with the code (and the client's state, if any)
    var callbackParams = new Dictionary<string, string?> { ["code"] = authorizationCode };
    if (state != null)
    {
        callbackParams["state"] = state;
    }
    return Results.Redirect(QueryHelpers.AddQueryString(redirectUri, callbackParams));
});

// 4. Endpoint: /token. Two grants: authorization_code (Steps 5-7 of the flow) and refresh_token.
app.MapPost("/token", async (HttpContext context) =>
{
    context.Response.Headers.CacheControl = "no-store";

    var form = await context.Request.ReadFormAsync();
    return form["grant_type"].ToString() switch
    {
        "" or "authorization_code" => ExchangeAuthorizationCode(context, form),
        "refresh_token" => ExchangeRefreshToken(context, form),
        _ => TokenError("unsupported_grant_type", "Supported grants: authorization_code, refresh_token")
    };
});

IResult TokenError(string error, string description) =>
    Results.Json(new { error, error_description = description }, statusCode: StatusCodes.Status400BadRequest);

string[] SplitScopes(string? scope) =>
    string.IsNullOrWhiteSpace(scope) ? [] : scope.Split(' ', StringSplitOptions.RemoveEmptyEntries);

IResult ExchangeAuthorizationCode(HttpContext context, IFormCollection form)
{
    string? code = form["code"];
    string? codeVerifier = form["code_verifier"];

    if (string.IsNullOrEmpty(code) || string.IsNullOrEmpty(codeVerifier))
    {
        return TokenError("invalid_request", "code and code_verifier are required");
    }

    if (!activeFlows.TryGetValue(code, out var session))
    {
        return TokenError("invalid_grant", "Code not found");
    }

    // PKCE Verification
    using var sha256 = SHA256.Create();
    string computedChallenge = Base64UrlEncode(sha256.ComputeHash(Encoding.UTF8.GetBytes(codeVerifier)));

    if (computedChallenge != session.CodeChallenge)
    {
        return TokenError("invalid_grant", "PKCE verification failed");
    }

    // If the client repeats these parameters at the token endpoint, they must match the authorization request
    string? tokenClientId = NullIfEmpty(form["client_id"].ToString());
    string? tokenRedirectUri = NullIfEmpty(form["redirect_uri"].ToString());
    string? tokenResource = NullIfEmpty(form["resource"].ToString());

    if ((tokenClientId != null && tokenClientId != session.ClientId) || (tokenRedirectUri != null && tokenRedirectUri != session.RedirectUri))
    {
        return TokenError("invalid_grant", "client_id or redirect_uri does not match the authorization request");
    }

    if (tokenResource != null && session.Resource != null && tokenResource != session.Resource)
    {
        return TokenError("invalid_target", "resource does not match the authorization request");
    }

    // Burn the code immediately so it's strictly single-use
    activeFlows.TryRemove(code, out _);

    // Every refresh token issued from this login shares a family id, so a replayed one can revoke them all.
    // The nonce (if the client sent one at /authorize) only ever goes into this first id_token, not into refreshed ones.
    return IssueTokens(context, session, Base64UrlEncode(RandomNumberGenerator.GetBytes(12)), null, tokenResource, session.Nonce);
}

// Refresh grant (RFC 6749 section 6). Each refresh token works once: using it returns a new one in the same family.
// Presenting one that was already used means it leaked, so the whole family is revoked (the OAuth security BCP's advice, and what Okta does).
IResult ExchangeRefreshToken(HttpContext context, IFormCollection form)
{
    string presented = form["refresh_token"].ToString();
    string? clientId = NullIfEmpty(form["client_id"].ToString());
    string? requestedScope = NullIfEmpty(form["scope"].ToString());
    string? tokenResource = NullIfEmpty(form["resource"].ToString());

    if (presented == "" || clientId == null)
    {
        return TokenError("invalid_request", "refresh_token and client_id are required");
    }

    // One message for every way a refresh token can be unusable, so a caller learns nothing about which tokens exist
    IResult invalid = TokenError("invalid_grant", "The refresh token is invalid, expired or revoked");

    AuthFlowSession original;
    string familyId;
    lock (refreshLock)
    {
        if (!refreshTokens.TryGetValue(presented, out var record))
        {
            return invalid;
        }

        if (record.ExpiresAt <= DateTimeOffset.UtcNow)
        {
            refreshTokens.TryRemove(presented, out _);
            return invalid;
        }

        if (record.Session.ClientId != clientId)
        {
            return invalid;
        }

        if (record.Used)
        {
            RevokeFamily(record.FamilyId);
            app.Logger.LogWarning("Refresh token reuse detected for {Account}: revoked all refresh tokens from that sign-in", record.Session.UserEmail);
            return invalid;
        }

        // A refresh may ask for fewer scopes than were granted, never more
        if (requestedScope != null && !SplitScopes(requestedScope).All(SplitScopes(record.Session.Scope).Contains))
        {
            return TokenError("invalid_scope", "The requested scope exceeds the scope originally granted");
        }

        if (tokenResource != null && record.Session.Resource != null && tokenResource != record.Session.Resource)
        {
            return TokenError("invalid_target", "resource does not match the original authorization");
        }

        record.Used = true;
        original = record.Session;
        familyId = record.FamilyId;
    }

    var current = ReevaluateSession(original);
    if (current == null)
    {
        RevokeFamily(familyId);
        return invalid;
    }

    return IssueTokens(context, current, familyId, requestedScope, tokenResource, null);
}

// Looks the user up again at every refresh, so a user who no longer exists cannot keep refreshing.
AuthFlowSession? ReevaluateSession(AuthFlowSession session) =>
    mockUserDatabase.TryGetValue(session.UserEmail, out var user)
        ? session with { UserName = user.Name, UserRoles = user.Roles }
        : null;

// A stable, per-user identifier that never changes (mirrors Entra ID's oid claim). Synthesised from the email
// since this mock has no real directory object id, but it is deterministic so it survives restarts.
string OidFor(string email) => new Guid(SHA256.HashData(Encoding.UTF8.GetBytes(email))[..16]).ToString();

// Entra ID's sub is pairwise: the same user gets a different, opaque sub for every different client_id, unlike oid
// which stays constant. Mirrored here so code written against sub can't accidentally treat it as a stable user key.
string Pairwise(string oid, string clientId) => Base64UrlEncode(SHA256.HashData(Encoding.UTF8.GetBytes($"{oid}|{clientId}")))[..27];

// Builds the token response for either grant
IResult IssueTokens(HttpContext context, AuthFlowSession session, string familyId, string? narrowedScope, string? tokenResource, string? nonce)
{
    string issuer = IssuerFor(context.Request);

    // The access token is audience-bound to the protected resource the client asked for (RFC 8707); with no resource it falls back to the client
    string audience = session.Resource ?? tokenResource ?? session.ClientId;

    // offline_access only asks for a refresh token. Like Entra ID, keep it out of the access token's own scope list.
    string[] granted = SplitScopes(narrowedScope ?? session.Scope);
    string[] apiScopes = granted.Where(s => s != "offline_access").ToArray();

    var accessTokenClaims = new Dictionary<string, object> { ["azp"] = session.ClientId, ["azpacr"] = "0" };
    if (apiScopes.Length > 0)
    {
        accessTokenClaims["scp"] = string.Join(' ', apiScopes);
    }
    string accessToken = GenerateJwtToken(rsaKey, issuer, audience, session.ClientId, session.UserEmail, session.UserName, session.UserRoles, familyId, null, new[] { "pwd" }, accessTokenClaims);

    // The id_token is for the client itself, so its audience is always the client_id. amr/azp/scp are access-token-only
    // in Entra ID's own token shape, but nonce (when the client sent one) only ever goes on the id_token.
    string idToken = GenerateJwtToken(rsaKey, issuer, session.ClientId, session.ClientId, session.UserEmail, session.UserName, session.UserRoles, familyId, nonce, null);

    var response = new Dictionary<string, object>
    {
        ["access_token"] = accessToken,
        ["token_type"] = "Bearer",
        ["expires_in"] = accessTokenSeconds,
        ["id_token"] = idToken
    };
    if (granted.Length > 0)
    {
        response["scope"] = string.Join(' ', granted);
    }

    // As with Entra ID and Okta, a refresh token is only issued when the client asked for the offline_access scope
    if (SplitScopes(session.Scope).Contains("offline_access"))
    {
        response["refresh_token"] = NewRefreshToken(session, familyId);
    }

    return Results.Json(response);
}

string NewRefreshToken(AuthFlowSession session, string familyId)
{
    var now = DateTimeOffset.UtcNow;
    foreach (var expired in refreshTokens.Where(kv => kv.Value.ExpiresAt <= now).Select(kv => kv.Key).ToList())
    {
        refreshTokens.TryRemove(expired, out _);
    }

    // An opaque random string: the client cannot read it, and only this IdP knows what it stands for.
    // Its lifetime slides: every refresh hands out a new token with a fresh full lifetime.
    string token = "rt_" + Base64UrlEncode(RandomNumberGenerator.GetBytes(32));
    refreshTokens[token] = new RefreshRecord(session, familyId, now.AddSeconds(refreshTokenSeconds));
    return token;
}

void RevokeFamily(string familyId)
{
    foreach (var key in refreshTokens.Where(kv => kv.Value.FamilyId == familyId).Select(kv => kv.Key).ToList())
    {
        refreshTokens.TryRemove(key, out _);
    }
}

IResult? ValidateAuthorizationRequest(string clientId, string redirectUri, string codeChallengeMethod, string? resource)
{
    // Unknown client or unregistered redirect: never redirect back, since that would be an open redirect
    if (!registeredClients.TryGetValue(clientId, out var allowedRedirects) || !allowedRedirects.Contains(redirectUri))
    {
        return Results.BadRequest(new { error = "invalid_request", error_description = "Unknown client_id or unregistered redirect_uri" });
    }

    if (codeChallengeMethod != "S256")
    {
        return Results.BadRequest(new { error = "invalid_request", error_description = "code_challenge_method must be S256" });
    }

    if (resource != null && !Uri.TryCreate(resource, UriKind.Absolute, out _))
    {
        return Results.BadRequest(new { error = "invalid_target", error_description = "resource must be an absolute URI" });
    }

    return null;
}

bool IsAcceptableRedirectUri(string? uri)
{
    if (!Uri.TryCreate(uri, UriKind.Absolute, out var parsed) || !string.IsNullOrEmpty(parsed.Fragment))
    {
        return false;
    }

    return parsed.Scheme == Uri.UriSchemeHttps || (parsed.Scheme == Uri.UriSchemeHttp && parsed.IsLoopback);
}

string? NullIfEmpty(string? value) => string.IsNullOrEmpty(value) ? null : value;

// Structural Token Builder. Claim names follow Microsoft Entra ID's v2.0 token shape (see access-token-claims-reference
// and id-token-claims-reference on Microsoft Learn) so code written against this mock needs minimal changes to work
// against a real Entra ID tenant later. amr is access-token-only and nonce is id_token-only, matching that reference.
string GenerateJwtToken(RSA rsa, string issuer, string audience, string clientId, string email, string name, string[] roles, string sid, string? nonce, string[]? amr, Dictionary<string, object>? extraClaims = null)
{
    string oid = OidFor(email);
    var header = new { alg = "RS256", typ = "JWT", kid };
    var payload = new Dictionary<string, object>
    {
        ["iss"] = issuer,
        ["idp"] = issuer,
        ["uti"] = Guid.NewGuid().ToString("N"), // unique per token; Entra ID's equivalent of the JWT-standard jti
        ["sub"] = Pairwise(oid, clientId),
        ["oid"] = oid,
        ["tid"] = TenantId,
        ["sid"] = sid,
        ["aud"] = audience,
        ["exp"] = DateTimeOffset.UtcNow.AddSeconds(accessTokenSeconds).ToUnixTimeSeconds(),
        ["iat"] = DateTimeOffset.UtcNow.ToUnixTimeSeconds(),
        ["nbf"] = DateTimeOffset.UtcNow.ToUnixTimeSeconds(),
        ["ver"] = "2.0",
        ["name"] = name,
        ["preferred_username"] = email,
        ["roles"] = roles // Injected roles exactly like Azure Entra ID
    };
    if (nonce != null)
    {
        payload["nonce"] = nonce;
    }
    if (amr != null)
    {
        payload["amr"] = amr;
    }
    foreach (var claim in extraClaims ?? new Dictionary<string, object>())
    {
        payload[claim.Key] = claim.Value;
    }

    string encodedHeader = Base64UrlEncode(Encoding.UTF8.GetBytes(JsonSerializer.Serialize(header)));
    string encodedPayload = Base64UrlEncode(Encoding.UTF8.GetBytes(JsonSerializer.Serialize(payload)));

    string stringToSign = $"{encodedHeader}.{encodedPayload}";
    byte[] signatureBytes = rsa.SignData(Encoding.UTF8.GetBytes(stringToSign), HashAlgorithmName.SHA256, RSASignaturePadding.Pkcs1);

    return $"{stringToSign}.{Base64UrlEncode(signatureBytes)}";
}

string Base64UrlEncode(byte[] input) => Convert.ToBase64String(input).Replace("=", "").Replace("+", "-").Replace("/", "_");

app.Run();

// Data container for active login flows
record AuthFlowSession(string ClientId, string RedirectUri, string CodeChallenge, string UserEmail, string UserName, string[] UserRoles, string? Resource, string? Scope, string? Nonce = null);

// A refresh token as the IdP remembers it. Used flips to true the one time it is exchanged.
class RefreshRecord(AuthFlowSession session, string familyId, DateTimeOffset expiresAt)
{
    public AuthFlowSession Session { get; } = session;
    public string FamilyId { get; } = familyId;
    public DateTimeOffset ExpiresAt { get; } = expiresAt;
    public bool Used { get; set; }
}
