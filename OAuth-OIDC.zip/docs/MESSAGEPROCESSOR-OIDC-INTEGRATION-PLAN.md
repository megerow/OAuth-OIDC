# Cross-repo OIDC integration: MiniOidcIdp → MessageProcessor.Api → ChatClient

> Planning document, written from the `MessageProcessor` repo's perspective and copied here
> for reference since this repo (the deployed MiniOidcIdp instance on AZWD-SB4) is one of the
> three systems involved. Phase 0 below is a config-only change to this repo (turning on an
> already-built persistence option); Phases 1-3 touch only `MessageProcessor`/`ChatClient` — see
> "Next step" below; implementation there is gated behind each consuming repo's own
> `spec-discovery` process.

## Context

`MiniOidcIdp` (this repo's IdP, deployed to IIS on AZWD-SB4 at `https://azwd-sb4/oidc`) uses
Windows/IWA sign-in and real WSGR AD groups mapped to a `roles` claim. The goal: MessageProcessor.Api's
MCP endpoint should know the real identity of the caller (not just a shared-secret attribution
string), in a way that's a low-friction swap to real Entra ID or Okta later — and today's
`ApiKeyAuthenticationHandler`/`ServiceOnBehalfOfAuthHandler` interim schemes in MessageProcessor.Api
stay untouched for existing callers. Beyond MCP tool filtering, the same roles are also meant to
extend ChatClient's existing AD-group-based Profile visibility feature (Phase 3 below), so profiles
can be gated by IdP role as well as AD group.

**Key constraint discovered during research:** MiniOidcIdp supports only interactive Authorization
Code + PKCE (no `client_credentials` grant, no client secrets — every client is public). There is no
way for ChatClient's backend to silently mint a service-level token; a real per-user token requires
ChatClient itself to become an OIDC relying party (login redirect, callback, session-bound token
storage, refresh). Because the IdP uses Windows/IWA, that redirect is silent for domain-joined users,
but it's still new architecture in ChatClient, not a header tweak.

**Decisions already made (with the user):**
- Both phases are in scope: (1) MessageProcessor.Api JWT-bearer validation, proven with a
  manually-obtained token, then (2) ChatClient becomes a real OIDC relying party so every real
  user's call carries their own identity.
- AD-group → role mapping coverage (`Idp:RoleMappings`) is explicitly **out of scope** — ship with
  the one existing `Admin` mapping; expanding it later is config-only, no code.
- Everything targets AZWD-SB4 **dev only** — no PROD MessageProcessor.Api, no PROD database, no
  PROD ChatClient.
- All changes are additive: existing `X-Api-Key` and `X-MP-Service-Key`/`X-MP-OnBehalf-User`
  callers, and every other ChatClient MCP integration (Weather Intel, Equibles, Azure DevOps,
  etc.), must be completely unaffected.
- Phase 2's OIDC login is triggered automatically via a top-level redirect at ChatClient session
  start (not lazily, per-MCP-source) so role data is reliably available for every
  Windows-authenticated user — but it must fail open (render the page anyway) rather than
  hard-block ChatClient if MiniOidcIdp is unreachable.
- Phase 3 is in scope: ChatClient's existing AD-group-based Profile filtering (`ProfileAcl`) is
  extended to also match on OIDC roles, OR'd with the existing group match — an additional way in,
  never a stricter gate on profiles that only use groups today.
- Phase 0 is in scope: MiniOidcIdp's in-memory persistence limitation gets actually fixed (not
  just tracked as a risk), by turning on its existing, already-built SQLite persistence option.

**Two facts verified directly against the code (not just agent research) that are load-bearing
for the design below:**
1. `MessageProcessor.Api/ClaimsPrincipalExtensions.cs:8` — `GetRoles()` hardcodes `ClaimTypes.Role`.
   A standard `JwtBearer` handler configured with `RoleClaimType="roles"` + `MapInboundClaims=false`
   (the pattern this same OAuth-OIDC repo's own sample APIs use) produces claims literally typed
   `"roles"`, **not** `ClaimTypes.Role`. Skipping an explicit remap means JWT-authenticated callers
   authenticate fine but silently see zero roles — tool filtering looks "wrong" with no error
   anywhere.
2. ChatClient has **no session/cookie mechanism today** (confirmed: no
   `SessionMiddleware`/`itsdangerous`/`set_cookie` anywhere in `backend/`). Identity is resolved
   fresh per request from IIS-forwarded Windows headers. This means Phase 2 needs a narrow,
   purpose-built store for OIDC tokens (and a short-lived one for the PKCE handshake) — not a
   general login/session system, and it doesn't touch the existing identity model at all.

## Next step (before any code)

This is pre-work for `spec-discovery`, not a substitute for it. Per `MessageProcessor/CLAUDE.md`'s
spec-first workflow, run the `spec-discovery` skill in `MessageProcessor` (suggested slug:
`oidc-bearer-auth`) using Phase 1 below as discovery input; no `Program.cs`/`appsettings.json` edits
happen until that repo's `PLAN.md` is `Status: Approved`. ChatClient has the same gate in its own
`CLAUDE.md` — a **second**, separate `spec-discovery` run is needed there before Phase 2 begins,
only after the Phase 1→2 checkpoint below is cleared. That single ChatClient `spec-discovery` pass
should cover both Phase 2 and Phase 3 together, since Phase 3 has no data to work with until
Phase 2's token storage exists. Phase 0 has no equivalent gate — this repo's own `CLAUDE.md`
doesn't mandate a spec-discovery workflow the way the other two repos do, and the change is small
enough (turning on an existing, already-built capability, not new functionality) not to need one.

## Phase 0 — MiniOidcIdp: turn on persistence (resolves the in-memory risk) — ✅ DONE, deployed and confirmed working on AZWD-SB4

The only `OAuth-OIDC-main` code/config change in this plan — everything needed already exists in
the repo (`MiniOidcIdp/Persistence/Migrations/Sqlite/...` and `.../SqlServer/...` are real,
checked-in EF Core migrations; turning this on runs them automatically via `AutoMigrate`, no new
migrations need to be written). Do this before or at the start of Phase 1, not after — it also
removes the timing pressure on Phase 1's manual proof, since a recycle mid-proof today invalidates
the dynamically-registered test client and any in-flight code/token.

**Provider choice: SQLite, not SQL Server** — this is a single dev IIS site with no existing SQL
Server footprint for MiniOidcIdp; SQLite only needs a file path the app-pool identity can write to,
and `C:\MiniOidc\` (already used for `role-mappings.json`, already has the right ACLs per the
README's icacls note) is a natural home for it.

**Config change** (`MiniOidcIdp/appsettings.Production.json`, or whatever file actually backs the
live `azwd-sb4` deployment) — safe to commit, these aren't secrets:
```json
"Persistence": {
  "Provider": "Sqlite",
  "ConnectionString": "Data Source=C:\\MiniOidc\\idp.db"
}
```

**`Persistence:EncryptionKey` must NOT go in that file or git.** It's a 32-byte base64 key
(`[Convert]::ToBase64String([System.Security.Cryptography.RandomNumberGenerator]::GetBytes(32))` in
PowerShell 7+) that `AesGcmProtector` uses to encrypt the signing key at rest — the app fails fast
at startup with a clear error if it's missing or the wrong size
(`Persistence/PersistenceExtensions.cs:33`). Set it as an IIS app-pool environment variable
(`Persistence__EncryptionKey`, double-underscore convention) — per earlier deployment experience on
this same box, machine/app-pool environment variable changes need a full `iisreset`, not just an
app-pool recycle, to take effect.

**One-time migration check before cutover:** today, live edits made at `/admin/roles` persist to a
JSON overlay file (`Idp:MappingsFile`, `C:\MiniOidc\role-mappings.json`), not to `appsettings.json`.
Enabling persistence swaps `RoleMappings` storage to SQL, seeded only from `Idp:RoleMappings` in
config (`SqlRoleMappingStore.SeedAsync`, `PersistenceExtensions.cs:96`) — any mappings added live
via the admin UI since deployment, if not also present in `appsettings.Production.json`, won't
carry over automatically. Check `C:\MiniOidc\role-mappings.json` on the server before cutover and
fold anything extra into config (or re-add it via `/admin/roles` after the switch) so nothing is
silently lost.

**Side benefit:** this also switches ASP.NET Core's own Data Protection keys (used for the admin
UI's anti-forgery tokens) to persist via `PersistKeysToDbContext`, so those survive restarts too —
today they're also implicitly in-memory, which wasn't called out as a separate risk but is fixed by
the same change.

**Verification:** after cutover, recycle the AZWD-SB4 app pool and confirm: a previously-issued
refresh token still works; the existing `Admin` role mapping is still present at `/admin/roles`; a
freshly dynamically-registered test client (for Phase 1's proof) survives the recycle too.

## Phase 1 — MessageProcessor.Api: add JWT-bearer as a third scheme — ✅ DONE, all tasks verified (see `docs/specs/oidc-bearer-auth/PLAN.md` in `MessageProcessor`)

**New config** — `MessageProcessor.Api/JwtOptions.cs` (new file, mirrors `ApiKeyOptions.cs`/
`OnBehalfOfOptions.cs` style): `Authority`, `Audience`, `SourceRoleClaimType` (default `"roles"`),
`RequireHttpsMetadata`, optional `MetadataRefreshSeconds`. Add an empty `"Jwt": {...}` placeholder
section to `appsettings.json` (matching the existing empty-default style of `ApiKeys`/`OnBehalfOf`);
real DEV values (`Authority=https://azwd-sb4/oidc`, `Audience=api://message-processor`) go in
`appsettings.Development.json` or user-secrets.

**Audience/resource value:** use the MCP endpoint's own canonical URL (e.g. `https://azwd-sb4/mcp`,
or whatever the DEV MessageProcessor.Api host's `/mcp` URL actually is) as the resource indicator,
per RFC 8707 / the MCP authorization spec — not an arbitrary app-id-URI string. A
standards-compliant MCP OAuth client (Claude Code CLI — see the revised proof step below) sets
`resource` to the MCP server's own URL automatically via Protected Resource Metadata discovery, so
this value doesn't need to be invented, it falls out of wherever `/mcp` is actually hosted.
`Jwt:Audience` must equal that same URL exactly. Phase 2's ChatClient RP should use the same value
for consistency.

**`Program.cs` changes** (extends the existing chain at lines 94–104, doesn't replace it):
- Add `.AddJwtBearer(JwtBearerDefaults.AuthenticationScheme, options => {...})` alongside the two
  existing `.AddScheme(...)` calls, with `Authority`/`Audience` from `JwtOptions`,
  `MapInboundClaims = false`, `TokenValidationParameters.NameClaimType = "preferred_username"`.
- **Required:** an `OnTokenValidated` event that copies each claim named `jwt.SourceRoleClaimType`
  ("roles") into a `new Claim(ClaimTypes.Role, ...)` on the identity — this is the fix for verified
  finding #1 above, and is load-bearing, not optional.
- Extend `ForwardDefaultSelector` with a third branch: check `X-MP-Service-Key` first (unchanged),
  then check for an `Authorization: Bearer ` prefix → forward to
  `JwtBearerDefaults.AuthenticationScheme`, else fall through to `ApiKey` (unchanged default). No
  existing caller's header shape overlaps with the new branch, so this ordering can't change any
  existing caller's outcome.
- Add `Microsoft.AspNetCore.Authentication.JwtBearer` package reference to
  `MessageProcessor.Api.csproj` (check current stable version for `net8.0`/`net10.0` at
  implementation time — don't guess a version).
- Add OAuth Protected Resource Metadata support so standards-compliant MCP clients (see the proof
  step below) can auto-discover MiniOidcIdp as the authorization server: use
  `ModelContextProtocol.AspNetCore.Authentication`'s `.AddMcp()` extension — the same pattern this
  repo's own `MiniMcpServer/Program.cs:43-52` already demonstrates — which maps
  `/.well-known/oauth-protected-resource` and adds the `WWW-Authenticate: Bearer
  resource_metadata=...` header to unauthenticated `/mcp` 401 responses. Confirm at implementation
  time that the pinned `ModelContextProtocol.AspNetCore` v1.4.1 actually includes this extension
  (it may need a version bump).

**Manual proof, using Claude Code CLI as the OAuth-aware MCP test client** (no ChatClient changes,
no hand-scripted client needed): this repo's own README already documents the exact pattern
(`claude mcp add --transport http mini-oidc http://localhost:5046/mcp` → `/mcp` → **Authenticate**)
against the sample `MiniMcpServer`; pointing it at MessageProcessor.Api's `/mcp` instead exercises
the real code being added. No manual client-registration step is needed — Claude Code drives RFC
7591 dynamic registration itself against `/register` (`Idp:AllowDynamicClientRegistration=true` is
already on).

1. `claude mcp add --transport http mp-oidc-test https://<dev-host>/mcp`, then `/mcp` → select
   `mp-oidc-test` → **Authenticate**. This should open a browser, silently complete Windows/IWA
   sign-in against `https://azwd-sb4/oidc`, and return with a working session — confirming
   Protected Resource Metadata discovery, dynamic client registration, PKCE, and token issuance all
   work end to end with zero manual token-wrangling.
2. Run while signed in as a non-Admin account → ask Claude to list available MCP tools
   (`tools/list`) → `AllowedRoles`-gated entries absent.
3. Run while signed in as an account in `WSGRDOM\WS – Innovation Development Team` (the one real
   `RoleMappings` entry) — requires completing step 1's browser login under that identity (e.g. a
   separate Windows session/`runas`, since the IWA challenge is tied to whichever Windows identity
   the browser runs as) → Admin-gated entries present. This is the empirical check that the
   `ClaimTypes.Role` remap actually worked — skipping it produces the *same wrong result* as step
   2, so both steps matter.
4. Ask Claude to actually invoke a couple of tools (not just list them) to confirm
   `CallToolAsync`'s entitlement re-check behaves the same way.
5. **Non-regression**, checked separately via curl/Postman since Claude Code's OAuth client doesn't
   exercise these paths: existing `X-Api-Key` request → 200 unchanged; existing
   `X-MP-Service-Key`/`X-MP-OnBehalf-User` request → 200 unchanged; a bad/expired bearer token or no
   `Authorization` header at all → 401 (falls through to `ApiKey`, fails closed as today).
6. `dotnet test MessageProcessor.Tests/MessageProcessor.Tests.csproj` stays green (29/30 baseline,
   per CLAUDE.md).

**Checkpoint before Phase 2:** steps 2–4 must pass with tokens bound to the MCP endpoint's own URL
as the resource — Phase 2's ChatClient RP should target that same resource value for consistency.

## Phase 2 — ChatClient becomes an OIDC relying party

Confirmed there's no session store to build on (see finding #2). Two new, narrow stores are needed,
not a general login system:

**Trigger mechanism — top-level redirect at session start, not lazy per-source.** Rather than
waiting for a user to touch an OIDC-opted-in MCP source, a new dependency (e.g.
`ensure_oidc_session(request, user, db, settings)` in `backend/app/auth/oidc.py`) runs on
ChatClient's page routes (`backend/app/api/pages.py`) and checks whether `user.sid` already has a
usable `OidcUserToken`. If not, it returns a 302 to `GET /auth/oidc/login?next=<original_path>`
instead of rendering the page; `/auth/oidc/login` stores `next` in the short-lived
`SessionMiddleware` session alongside `state`/`code_verifier`, and `/auth/oidc/callback` redirects
there on success. Because MiniOidcIdp uses Windows/IWA, this round trip is silent for domain-joined
users — one extra redirect hop at the start of a session, no visible login UI. This applies only to
page routes, not JSON/API routes — an AJAX call shouldn't get redirected mid-flight.

**Fail open, don't hard-block the app.** If the redirect round trip fails or times out (MiniOidcIdp
unreachable or mid-recycle), `ensure_oidc_session` should let the page render anyway with no OIDC
token yet, rather than blocking ChatClient's core chat function on an external dependency — the user
simply keeps AD-group-only profile/tool access until a later session succeeds. See Risks below —
this matters more once every session depends on this round trip, not just whichever feature opted
in.

- **Durable per-user token store** — new `OidcUserToken` model in `backend/app/db/models.py` (near
  the existing `McpSourceUserCredential`), keyed by `user_sid` (must be `Unicode`, not `String`, per
  this repo's existing SQL Server gotcha): `access_token`, `refresh_token`, `id_token`, `scope`,
  `expires_at`. Add DDL to `sql/001_schema.sql` and the additive create-if-missing step in
  `backend/app/db/migrate.py`.
- **Short-lived handshake state** — Starlette `SessionMiddleware` (new dependency: `itsdangerous`),
  `max_age≈600s`, `same_site=lax`, `https_only` in prod, holding only the OAuth `state`/PKCE
  `code_verifier` — never identity or tokens, so it doesn't touch or duplicate the existing
  Windows-header identity model.

**New/changed files:**
- `backend/app/auth/oidc.py` (new) — authlib client registration; `get_valid_oidc_access_token(db,
  user, settings)` (refreshes if within a margin of `expires_at`, mirroring `MiniFlaskClient/app.py`'s
  refresh-margin pattern); `save_oidc_token(...)`. **Required:** a per-user `asyncio.Lock`
  (module-level dict, same idiom as `backend/app/auth/windows.py`'s TTL-cache dicts) around refresh
  — MiniOidcIdp's refresh grant is single-use with reuse-detection that revokes the whole sign-in
  family, so two concurrent tool calls refreshing the same token would silently sign the user out
  mid-chat. Correct today because ChatClient runs as a single worker process (`web.config`'s
  `processesPerApplication="1"`) — note that this stops being sufficient if that ever changes.
- `backend/app/api/oidc_routes.py` (new) — `GET /auth/oidc/login` (reads `next` from the query
  string, stashes it in the session alongside `state`/`code_verifier`, then authlib
  `authorize_redirect`, passing the same MCP-endpoint-URL `resource` value as Phase 1's
  `Jwt:Audience`), `GET /auth/oidc/callback`
  (`authorize_access_token` → `save_oidc_token` → redirect to the stashed `next`, defaulting to
  `/`), `POST /auth/oidc/logout` (back-channel revoke +
  front-channel end-session, mirroring `MiniFlaskClient/app.py`'s logout). Mount in
  `backend/app/main.py` alongside the existing routers.
- `backend/app/config.py` — new `Settings` fields: `oidc_authority`, `oidc_client_id`,
  `oidc_redirect_uri`, `oidc_resource` (must match Phase 1's `Jwt:Audience` — the MCP endpoint's
  own canonical URL, not an arbitrary app-id-URI), `oidc_scopes`, `oidc_session_secret_key`. Real values flow through the same Azure
  DevOps Library variable group → app-pool registry env path already used for
  `mp_onbehalf_service_key`.
- `backend/app/services/mcp_gateway.py` — new `async def _oidc_headers(self, source)`, same
  fail-closed shape as the existing `_onbehalf_headers` (lines 87–110): returns `{}` unless the
  source's `env_json` has a new opt-in flag (`mcp_oidc_login: true`, set via the *existing* generic
  `PATCH /admin/mcp-sources/{id}` env-edit endpoint — no new admin UI needed) and a valid/refreshable
  token exists for `self.user`. Plugged into the header merge at `_http_streams` (line 312) and
  `_sse_streams` (line 329): `{**_http_headers(source), **self._onbehalf_headers(source),
  **(await self._oidc_headers(source))}`. Note `mp_on_behalf_of` and `mcp_oidc_login` are
  alternative strategies for the same target — don't set both on one source (MessageProcessor.Api's
  selector would send the bearer token but ignore it in favor of ServiceOnBehalfOf).
- `backend/requirements.txt` — add `authlib` (standards-based OIDC client, so a later Entra
  ID/Okta swap is a config change) and `itsdangerous`.

**Tests to add:** extend `backend/tests/test_mcp_gateway.py` mirroring the existing
`_onbehalf_headers` test pattern (present/absent/not-signed-in/refresh-before-call/refresh-failure
cases); new `backend/tests/test_oidc_auth.py` for the refresh-margin and per-user-lock behavior
(assert exactly one refresh fires under simulated concurrent calls); route tests for
`/auth/oidc/login` and `/auth/oidc/callback`, including `next`-redirect preservation and the
fail-open path when the IdP is unreachable. Confirm existing
`test_mcp_gateway.py`/`test_api_routes.py` pass unmodified. A real end-to-end pass (browser login →
callback → an actual MCP tool call through the opted-in source) is a manual smoke test, same
category as Phase 1's proof.

**Checkpoint before Phase 3:** Phase 2's auto-redirect and token storage must be working and
verified fail-open-safe before layering Profile role-filtering on top of it.

## Phase 3 — ChatClient: filter Profiles by OIDC role

Builds directly on Phase 2's `OidcUserToken` — there's no other source for "role as returned by the
IdP" in this app. Today, `Profile` visibility (`backend/app/services/profiles.py`) is gated only by
AD-group membership via `ProfileAcl` (`backend/app/db/models.py:601-617`, `principal_type` always
written as the literal `"ad_group"`) matched against `CurrentUser.groups`
(`backend/app/auth/windows.py`); `user_can_access_profile()` (`profiles.py:56-73`) is the single
function that does the actual matching.

- **`CurrentUser` gets a new `roles: list[str]` field**, populated wherever `resolve_identity()`
  builds the object: look up the signed-in user's `OidcUserToken` by `user_sid`, decode the
  `access_token`'s `roles` claim (JWT payload, base64url — no signature re-verification needed since
  authlib already validated it at token-issuance time; just sanity-check `exp`), defaulting to `[]`
  on any failure (missing token, decode error, expired) so this never blocks identity resolution.
- **`ProfileAcl.principal_type` gets a real second value, `"oidc_role"`**, alongside the existing
  always-written `"ad_group"` — finally using the column for its intended purpose instead of
  leaving it an inert default (confirmed: it exists today but is never read).
- **`user_can_access_profile()`** gains role-matching alongside its existing group-matching,
  combined with **OR** semantics (per the user's decision): a user sees the profile if their groups
  intersect the group-ACL *or* their roles intersect the role-ACL. An empty ACL on both axes still
  means nobody can see it, same as today's "empty ACL = denied" convention — adding role entries to
  a profile is an additional way in, never a stricter requirement than what's already there.
- **Admin UI** (`backend/app/templates/admin.html`'s profile modal) gets a second "Allowed roles"
  textarea alongside the existing "Allowed groups" one (`#profile-groups`); `set_profile_acls()`
  (`profiles.py:142-151`) takes both lists and writes `ProfileAcl` rows differentiated by
  `principal_type`.
- **Known duplicate to update in parallel:** `backend/app/auth/windows.py::_admin_profile_member`
  is a deliberate, separately-maintained copy of the admin-profile-membership check (kept apart to
  avoid a circular import, per its own docstring) — if the admin profile should also be reachable
  via role, this needs the identical change made there too, consistent with this codebase's
  established convention of duplicating small ACL logic per domain rather than sharing it.
- **Tests:** extend `backend/tests/test_profiles.py`'s `make_profile` fixture with a parallel
  `roles=(...)` parameter, and mirror the existing group-based tri-state test sweep
  (role-match-granted, role-mismatch-denied, OR-combination with groups, case-insensitivity,
  override-still-wins, disabled-still-wins).

## Risks flagged, not solved, by this plan

- ~~MiniOidcIdp runs in-memory~~ — **addressed by Phase 0** (turns on
  `Persistence:Provider=Sqlite`), rather than left as a tracked-but-unsolved risk. Do Phase 0
  before Phase 1's manual proof so the proof itself isn't vulnerable to a mid-test recycle.
- **Secret-at-rest:** the existing `McpSourceUserCredential.credential_json` precedent stores
  secrets as plaintext JSON; a refresh token is a more powerful, longer-lived secret than a
  single-source PAT. Worth a deliberate decision at implementation time (accept the existing
  precedent vs. add encryption) rather than defaulting silently.
- Audience/resource-value coordination has no compile-time check across repos — a typo in
  `Jwt:Audience` vs. what a client requests produces a silent 401, not a build error. Using the MCP
  endpoint's own URL rather than an invented string reduces this for standards-compliant clients
  that discover it via Protected Resource Metadata (Claude Code, and ChatClient if Phase 2 also
  does discovery instead of hardcoding `oidc_resource`), but doesn't eliminate manual configuration
  on the API side.
- Whether `ModelContextProtocol.AspNetCore` v1.4.1 (the version currently pinned) includes the
  `.AddMcp()` Protected Resource Metadata extension, or whether a version bump is needed —
  unconfirmed, check at implementation time.
- **MiniOidcIdp becomes a hard dependency for ChatClient page loads, not just an optional one**,
  once Phase 2 auto-triggers the OIDC round trip at session start: if AZWD-SB4's `/oidc` site is
  unreachable or mid-recycle, every new ChatClient session hits that failure, not just whichever
  feature opted into OIDC. Mitigated by the fail-open requirement on `ensure_oidc_session` (render
  the page anyway with empty roles) rather than hard-blocking — but this needs to actually be
  verified to work, not just assumed.

## Verification summary

- Phase 0: recycle the AZWD-SB4 app pool after cutover and confirm a refresh token, the existing
  `Admin` role mapping, and a dynamically-registered test client all survive it.
- Phase 1: the Claude-Code-CLI-driven checklist above, run against MessageProcessor.Api on a
  dev/test DB (never PROD — check the connection string first per CLAUDE.md), plus the existing
  `dotnet test` suite staying green.
- Phase 2: automated tests listed above, plus one real manual smoke test (browser login through
  AZWD-SB4's `/oidc`, callback, and a live MCP tool call), plus confirming the
  auto-redirect-at-session-start behavior (new session → silent redirect round trip → lands back on
  the originally-requested page) and that a simulated MiniOidcIdp outage doesn't block page load
  (fail-open check) — before considering the phase done.
- Phase 3: the extended `test_profiles.py` sweep, plus a manual check that a profile configured
  with only a role-ACL (no group-ACL) correctly becomes visible/invisible for a real signed-in
  user.

## Repos touched by this plan

1. **`MessageProcessor`** — Phase 1: new `MessageProcessor.Api/JwtOptions.cs`, a `Jwt` section in
   `appsettings.json`, `Program.cs` auth-chain changes, a new package reference.
2. **`ChatClient`** (`ChatClient-development`) — Phase 2: new `backend/app/auth/oidc.py`,
   `backend/app/api/oidc_routes.py`, a new `OidcUserToken` model/table, changes to
   `mcp_gateway.py`, `config.py`, `main.py`, `requirements.txt`. Phase 3 (same repo): a new
   `roles` field on `CurrentUser`, a second `ProfileAcl.principal_type` value, admin UI and
   `profiles.py`/`windows.py` changes, no new tables.
3. **`OAuth-OIDC-main`** (this repo) — Phase 0: a `Persistence` config change in
   `appsettings.Production.json` (or whatever backs the live deployment) turning on SQLite
   persistence; `Persistence:EncryptionKey` set as an IIS app-pool environment variable, not
   committed. No EF Core migrations need to be written — they already exist in the repo. The Phase
   1 manual proof separately uses dynamic client registration (`POST /register`), an API call
   against the running server, not a repo commit.
