using System.Text;
using Microsoft.AspNetCore.Antiforgery;

// Server-rendered HTML for /admin/roles. Every dynamic value goes through Html() because group names come from the directory.
static class AdminPage
{
    public static string Render(PathString pathBase, IdpMode mode, IReadOnlyList<UserReport> users, IReadOnlyList<RoleMapping> mappings, IReadOnlyList<ActiveSession>? sessions, bool canEdit, string? adminGroup, AntiforgeryTokenSet tokens, string? notice, IReadOnlyCollection<ClientInfo> staticClients, IReadOnlyList<ClientInfo> registeredClients)
    {
        static string Html(string? s) => Ui.Html(s);

        string tokenField = $"<input type='hidden' name='{Html(tokens.FormFieldName)}' value='{Html(tokens.RequestToken)}' />";
        var sb = new StringBuilder();

        sb.Append("<h1>Roles and group mappings</h1>");
        sb.Append($"<p>Authentication mode: <b>{Html(mode.ToString())}</b>. Roles are worked out at sign-in, so a change only affects new sign-ins. Tokens already issued keep their old roles until they expire.</p>");

        if (!string.IsNullOrEmpty(notice))
        {
            sb.Append($"<p class='alert alert-info'>{Html(notice)}</p>");
        }

        sb.Append("<div class='card'><h2>Roles returned by the IdP</h2>");
        foreach (var user in users)
        {
            sb.Append($"<h3>{Html(user.Name)} <small>({Html(user.Account)})</small></h3>");
            sb.Append($"<p>Token <code>sub</code>: <code>{Html(user.Subject)}</code></p>");
            sb.Append("<p>Roles in the token: ");
            sb.Append(user.Roles.Length == 0
                ? "<i>none</i>"
                : string.Join(" ", user.Roles.Select(r => $"<span class='role'>{Html(r)}</span>")));
            sb.Append("</p>");

            sb.Append("<table><tr><th>Group</th><th>SID</th><th>Mapped to</th>");
            sb.Append(canEdit ? "<th>Map this group to a role</th></tr>" : "</tr>");
            foreach (var group in user.Groups)
            {
                string key = group.Name ?? group.Sid ?? "";
                var mappedRoles = mappings
                    .Where(m => string.Equals(m.Group, group.Name, StringComparison.OrdinalIgnoreCase) || string.Equals(m.Group, group.Sid, StringComparison.OrdinalIgnoreCase))
                    .Select(m => m.Role)
                    .ToList();

                sb.Append($"<tr><td>{Html(group.Name ?? "(name not resolved)")}</td><td><code>{Html(group.Sid)}</code></td>");
                sb.Append($"<td>{(mappedRoles.Count == 0 ? "" : string.Join(" ", mappedRoles.Select(r => $"<span class='role'>{Html(r)}</span>")))}</td>");
                if (canEdit)
                {
                    sb.Append($@"<td><form class='inline' method='post' action='{pathBase}/admin/roles/mappings'>{tokenField}
                        <input type='hidden' name='group' value='{Html(key)}' />
                        <input type='text' name='role' placeholder='Role name' required style='width:10rem' />
                        <button type='submit' class='btn btn-sm'>Add</button></form></td>");
                }
                sb.Append("</tr>");
            }
            sb.Append("</table>");
        }
        sb.Append("</div>");

        sb.Append("<div class='card'><h2>Group to role mappings</h2>");
        sb.Append("<table><tr><th>Group (name or SID)</th><th>Role</th>");
        sb.Append(canEdit ? "<th></th></tr>" : "</tr>");
        foreach (var mapping in mappings)
        {
            sb.Append($"<tr><td>{Html(mapping.Group)}</td><td><span class='role'>{Html(mapping.Role)}</span></td>");
            if (canEdit)
            {
                sb.Append($@"<td><form class='inline' method='post' action='{pathBase}/admin/roles/mappings/delete'>{tokenField}
                    <input type='hidden' name='group' value='{Html(mapping.Group)}' />
                    <input type='hidden' name='role' value='{Html(mapping.Role)}' />
                    <button type='submit' class='btn btn-secondary btn-sm'>Remove</button></form></td>");
            }
            sb.Append("</tr>");
        }
        sb.Append("</table>");

        if (canEdit)
        {
            sb.Append($@"<h3>Add a mapping</h3>
                <form method='post' action='{pathBase}/admin/roles/mappings'>{tokenField}
                    <input type='text' name='group' placeholder='DOMAIN\Group or SID' required style='width:20rem; max-width:100%' />
                    <input type='text' name='role' placeholder='Role name' required style='width:10rem' />
                    <button type='submit' class='btn'>Add</button>
                </form>");
        }
        else
        {
            sb.Append(string.IsNullOrWhiteSpace(adminGroup)
                ? "<p class='muted'><i>Editing is disabled: no <code>Idp:AdminGroup</code> is configured.</i></p>"
                : $"<p class='muted'><i>Editing needs membership in <code>{Html(adminGroup)}</code>.</i></p>");
        }
        sb.Append("</div>");

        if (sessions != null)
        {
            sb.Append("<div class='card'><h2>Active sign-ins</h2>");
            sb.Append("<p>Users holding a refresh token, which lets their application renew tokens without asking them to sign in again. Ending their sign-ins stops that within moments. ");
            sb.Append("Access tokens already issued keep working until they expire.</p>");
            if (sessions.Count == 0)
            {
                sb.Append("<p class='muted'><i>None right now.</i></p>");
            }
            else
            {
                sb.Append("<table><tr><th>User</th><th>Sign-ins</th><th>Latest token issued</th>");
                sb.Append(canEdit ? "<th></th></tr>" : "</tr>");
                foreach (var session in sessions)
                {
                    sb.Append($"<tr><td>{Html(session.Name)} <small>({Html(session.Account)})</small></td><td>{session.SignIns}</td><td>{Html(session.LastIssued.ToLocalTime().ToString("yyyy-MM-dd HH:mm:ss"))}</td>");
                    if (canEdit)
                    {
                        sb.Append($@"<td><form class='inline' method='post' action='{pathBase}/admin/roles/sessions/revoke'>{tokenField}
                            <input type='hidden' name='subject' value='{Html(session.Subject)}' />
                            <button type='submit' class='btn btn-secondary btn-sm'>End sign-ins</button></form></td>");
                    }
                    sb.Append("</tr>");
                }
                sb.Append("</table>");
            }
            sb.Append("</div>");
        }

        sb.Append("<div class='card'><h2>OIDC clients</h2>");
        sb.Append("<p>A client fixed in configuration (<code>Idp:Clients</code>) or registered here as trusted skips the consent page at <code>/authorize</code>. ");
        sb.Append("A client that registered itself at <code>/register</code> does not, until an admin re-registers it here.</p>");

        if (staticClients.Count > 0)
        {
            sb.Append("<h3>Fixed in configuration</h3><table><tr><th>Client ID</th><th>Redirect URIs</th></tr>");
            foreach (var client in staticClients)
            {
                sb.Append($"<tr><td><code>{Html(client.ClientId)}</code></td><td>{string.Join("<br/>", client.RedirectUris.Select(Html))}</td></tr>");
            }
            sb.Append("</table>");
        }

        sb.Append("<h3>Registered</h3>");
        if (registeredClients.Count == 0)
        {
            sb.Append("<p class='muted'><i>None right now.</i></p>");
        }
        else
        {
            sb.Append("<table><tr><th>Client ID</th><th>Name</th><th>Redirect URIs</th><th>Consent</th>");
            sb.Append(canEdit ? "<th></th></tr>" : "</tr>");
            foreach (var client in registeredClients)
            {
                sb.Append($"<tr><td><code>{Html(client.ClientId)}</code></td><td>{Html(client.Name ?? "")}</td>");
                sb.Append($"<td>{string.Join("<br/>", client.RedirectUris.Select(Html))}</td>");
                sb.Append(client.Dynamic ? "<td>Required</td>" : "<td>Skipped (trusted)</td>");
                if (canEdit)
                {
                    sb.Append($@"<td><form class='inline' method='post' action='{pathBase}/admin/roles/clients/remove'>{tokenField}
                        <input type='hidden' name='client_id' value='{Html(client.ClientId)}' />
                        <button type='submit' class='btn btn-secondary btn-sm'>Remove</button></form></td>");
                }
                sb.Append("</tr>");
            }
            sb.Append("</table>");
        }

        if (canEdit)
        {
            sb.Append($@"<h3>Register a trusted client</h3>
                <p class='muted'>Skips the consent page immediately -- use this instead of a config change + restart when you just need to test the silent sign-in path.</p>
                <form method='post' action='{pathBase}/admin/roles/clients/register'>{tokenField}
                    <input type='text' name='client_id' placeholder='client_id (blank to generate one)' style='width:20rem; max-width:100%' /><br/>
                    <input type='text' name='name' placeholder='Display name (optional)' style='width:20rem; max-width:100%' /><br/>
                    <textarea name='redirect_uris' placeholder='One redirect URI per line' required rows='3' style='width:20rem; max-width:100%'></textarea><br/>
                    <button type='submit' class='btn'>Register as trusted</button>
                </form>");
        }
        sb.Append("</div>");

        string nav = $"<a class='active' href='{pathBase}/admin/roles'>Roles &amp; mappings</a><a href='{pathBase}/admin/roles.json'>Raw JSON</a>";
        return Ui.SidebarPage("Roles", nav, $"Mode: <b>{Html(mode.ToString())}</b>", sb.ToString());
    }
}
