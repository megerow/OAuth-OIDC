using System.Runtime.Versioning;
using System.Security.Principal;
using System.Text.Json;
using System.Text.RegularExpressions;

// Where the IdP gets the signed-in user's identity and groups from
enum IdpMode { Persona, WindowsKestrel, WindowsIis }

class IdpOptions
{
    public IdpMode AuthenticationMode { get; set; } = IdpMode.Persona;
    public bool EnableAdminUi { get; set; }
    public string? AdminGroup { get; set; }
    public string? MappingsFile { get; set; }

    // When set, this is the issuer in every token and in the metadata. Otherwise it is taken from the request's address,
    // which is only safe when nothing can send a made-up Host header (and needs care behind a load balancer).
    public string? Issuer { get; set; }

    // A fixed mock tenant id, the same for every user, mirroring Entra ID's tid claim. There is only one "tenant" here.
    public string TenantId { get; set; } = "a1b2c3d4-e5f6-4a1b-8c2d-1a2b3c4d5e6f";

    // Set this when the app is deployed under a sub-path (e.g. an IIS Application at /oidc rather than a site's root).
    // IIS/ANCM sets this automatically for incoming requests, but setting it here too works around a known .NET 10
    // regression where the first request after a cold start can see an empty PathBase, and makes the app testable
    // under a sub-path with plain `dotnet run` (no IIS needed).
    public string? PathBase { get; set; }

    // Turn off /register to stop strangers adding clients (and rows) to the IdP
    public bool AllowDynamicClientRegistration { get; set; } = true;

    public List<ClientOptions> Clients { get; set; } = new();
    public List<RoleMapping> RoleMappings { get; set; } = new();
    public List<Persona> Personas { get; set; } = new();
}

// Maps a group (name such as DOMAIN\Group, or a SID) to an application role that goes into the token
record RoleMapping
{
    public string Group { get; init; } = "";
    public string Role { get; init; } = "";
}

// A fake user for Persona mode (Linux and other non-Windows development)
class Persona
{
    public string Email { get; set; } = "";
    public string Password { get; set; } = "";
    public string Name { get; set; } = "";
    public string Sid { get; set; } = "";
    public string[] Groups { get; set; } = [];
}

record GroupInfo(string? Name, string? Sid);

// The signed-in user as the rest of the IdP sees it, whichever authenticator produced it
record IdpUser(string Subject, string Account, string Name, Func<string, bool> IsInGroup, Func<IReadOnlyList<GroupInfo>> ListGroups);

record MappingMatch(string Group, string Role, bool Matched);

record UserReport(string Subject, string Account, string Name, IReadOnlyList<GroupInfo> Groups, IReadOnlyList<MappingMatch> Mappings, string[] Roles);

static class IdpUsers
{
    public static string[] ResolveRoles(IdpUser user, IEnumerable<RoleMapping> mappings) =>
        mappings.Where(m => user.IsInGroup(m.Group)).Select(m => m.Role).Distinct().ToArray();

    public static UserReport Report(IdpUser user, IReadOnlyList<RoleMapping> mappings) =>
        new(user.Subject, user.Account, user.Name, user.ListGroups(),
            mappings.Select(m => new MappingMatch(m.Group, m.Role, user.IsInGroup(m.Group))).ToList(),
            ResolveRoles(user, mappings));

    public static IdpUser FromPersona(Persona p) => new(
        Subject: p.Sid,
        Account: p.Email,
        Name: p.Name,
        IsInGroup: group => p.Groups.Contains(group, StringComparer.OrdinalIgnoreCase),
        ListGroups: () => p.Groups.Select(g => new GroupInfo(g, null)).ToList());

    [SupportedOSPlatform("windows")]
    public static IdpUser FromWindows(WindowsIdentity identity)
    {
        var principal = new WindowsPrincipal(identity);

        // Accepts a group name (DOMAIN\Group) or a SID; a name that cannot be resolved counts as "not a member"
        bool IsInGroup(string group)
        {
            try
            {
                return group.StartsWith("S-1-", StringComparison.OrdinalIgnoreCase)
                    ? principal.IsInRole(new SecurityIdentifier(group))
                    : principal.IsInRole(group);
            }
            catch (SystemException)
            {
                return false;
            }
        }

        IReadOnlyList<GroupInfo> ListGroups() =>
            (identity.Groups ?? new IdentityReferenceCollection())
                .Select(sid => new GroupInfo(TryTranslate(sid), sid.Value))
                .OrderBy(g => g.Name ?? g.Sid)
                .ToList();

        return new IdpUser(identity.User?.Value ?? identity.Name, identity.Name, identity.Name, IsInGroup, ListGroups);
    }

    [SupportedOSPlatform("windows")]
    static string? TryTranslate(IdentityReference reference)
    {
        try
        {
            return reference.Translate(typeof(NTAccount)).Value;
        }
        catch (SystemException)
        {
            return null;
        }
    }
}

// The rules for a mapping, shared by every store so a file and a database accept exactly the same input
static partial class RoleMappingRules
{
    // Returns an error message, or null when the mapping is acceptable
    public static string? Validate(RoleMapping mapping)
    {
        if (string.IsNullOrWhiteSpace(mapping.Group) || mapping.Group.Length > 256 || mapping.Group.Any(char.IsControl))
        {
            return "Group is required (up to 256 characters).";
        }

        if (!RoleName().IsMatch(mapping.Role))
        {
            return "Role must be 1-64 characters: letters, digits, and _ . : -";
        }

        return null;
    }

    [GeneratedRegex("^[A-Za-z0-9_.:-]{1,64}$")]
    private static partial Regex RoleName();
}

// Holds the group-to-role mappings in a JSON file. It starts from the configured mappings, and edits made through the admin page
// are saved to the file, which then wins over the configured defaults. Used when no database is configured.
sealed class FileRoleMappingStore : IRoleMappingStore
{
    static readonly JsonSerializerOptions FileJson = new() { WriteIndented = true };

    readonly object gate = new();
    readonly string path;
    List<RoleMapping> mappings;

    public FileRoleMappingStore(IEnumerable<RoleMapping> configured, string path)
    {
        this.path = path;
        mappings = configured.ToList();

        if (File.Exists(path))
        {
            mappings = JsonSerializer.Deserialize<List<RoleMapping>>(File.ReadAllText(path)) ?? mappings;
        }
    }

    public Task<IReadOnlyList<RoleMapping>> SnapshotAsync()
    {
        lock (gate)
        {
            return Task.FromResult<IReadOnlyList<RoleMapping>>(mappings.ToList());
        }
    }

    public Task<string?> AddAsync(RoleMapping mapping)
    {
        var error = RoleMappingRules.Validate(mapping);
        if (error != null)
        {
            return Task.FromResult<string?>(error);
        }

        lock (gate)
        {
            if (mappings.Contains(mapping))
            {
                return Task.FromResult<string?>("That mapping already exists.");
            }

            return Task.FromResult(Save(mappings.Append(mapping).ToList()));
        }
    }

    public Task<string?> RemoveAsync(RoleMapping mapping)
    {
        lock (gate)
        {
            if (!mappings.Contains(mapping))
            {
                return Task.FromResult<string?>("That mapping no longer exists.");
            }

            return Task.FromResult(Save(mappings.Where(m => m != mapping).ToList()));
        }
    }

    string? Save(List<RoleMapping> updated)
    {
        try
        {
            Directory.CreateDirectory(Path.GetDirectoryName(Path.GetFullPath(path))!);
            string temp = path + ".tmp";
            File.WriteAllText(temp, JsonSerializer.Serialize(updated, FileJson));
            File.Move(temp, path, overwrite: true);
            mappings = updated;
            return null;
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
        {
            return $"Could not save the mappings file ({path}): {ex.Message}";
        }
    }
}
